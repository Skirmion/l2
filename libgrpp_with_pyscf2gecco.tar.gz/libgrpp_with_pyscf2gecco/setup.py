"""
Этот setup.py использует CMake для сборки C/C++ расширения,
а затем копирует весь проект в site‑packages
"""

import os
import subprocess
import shutil
import platform
import site
from setuptools import setup, find_packages, Extension
from setuptools.command.build_ext import build_ext
from setuptools.command.install import install


def readme():
    """Читает содержимое README.md для длинного описания."""
    with open("README.md", encoding="utf-8") as f:
        return f.read()


class CMakeExtension(Extension):
    """
    Расширение, которое будет собираться с помощью CMake.
    
    Параметры:
      name         — имя расширения, как будет импортироваться в Python
      cmake_target — имя цели, которую генерирует CMake (например, 'liblibgrpp')
      sourcedir    — директория с CMakeLists.txt (например, 'libgrpp')
    """
    def __init__(self, name, cmake_target, sourcedir=''):
        # sources оставляем пустым, так как сборка производится CMake
        super().__init__(name, sources=[])
        self.cmake_target = cmake_target
        self.sourcedir = os.path.abspath(sourcedir)


class CMakeBuild(build_ext):
    """
    Кастомная команда сборки, которая вызывает CMake и make,
    а затем копирует скомпилированную библиотеку (.so, .dll, .dylib)
    во внутреннюю папку пакета (libgrpp/libgrpp).
    """
    def run(self):
        # Для каждого расширения запускаем CMake и make
        for ext in self.extensions:
            build_temp = os.path.abspath(self.build_temp)
            os.makedirs(build_temp, exist_ok=True)
            # Конфигурируем проект с помощью CMake
            subprocess.check_call(['cmake', ext.sourcedir], cwd=build_temp)
            # Строим проект с помощью make
            subprocess.check_call(['make'], cwd=build_temp)
        # Продолжаем стандартную сборку
        super().run()

    def build_extension(self, ext):
        # Определяем расширение библиотеки в зависимости от ОС
        system = platform.system()
        lib_ext = {
            "Windows": ".dll",
            "Linux": ".so",
            "Darwin": ".dylib"
        }.get(system)
        if lib_ext is None:
            raise OSError(f"Unsupported platform: {system}")

        build_temp = os.path.abspath(self.build_temp)
        # Формируем путь к скомпилированной библиотеке
        built_lib = os.path.join(build_temp, ext.cmake_target + lib_ext)
        if not os.path.exists(built_lib):
            raise RuntimeError(f"Built library not found: {built_lib}")

        # Копируем библиотеку во внутреннюю папку пакета:
        # итоговая структура должна быть site-packages/libgrpp/libgrpp/liblibgrpp.so
        here = os.path.abspath(os.path.dirname(__file__))
        dest_dir = os.path.join(here, "libgrpp", "libgrpp")
        os.makedirs(dest_dir, exist_ok=True)
        dest_file = os.path.join(dest_dir, ext.cmake_target + lib_ext)
        shutil.copy(built_lib, dest_file)
        print(f"✅ Copied compiled library to {dest_file}")


class CustomInstallCommand(install):
    """
    Кастомная команда установки, которая после стандартной установки
    копирует весь проект в директорию site-packages под именем "libgrpp".
    """
    def run(self):
        # Выполняем стандартную установку
        install.run(self)

        # Определяем целевую директорию site-packages для установки (--user)
        site_packages = site.getusersitepackages()
        dest_dir = os.path.join(site_packages, "libgrpp")

        # Удаляем предыдущую версию, если она существует
        if os.path.exists(dest_dir):
            shutil.rmtree(dest_dir)
        os.makedirs(dest_dir, exist_ok=True)

        # Копируем весь проект (все файлы и папки) в dest_dir.
        # При этом скомпилированная библиотека уже лежит во внутренней папке (libgrpp/libgrpp)
        src_dir = os.getcwd()
        for item in os.listdir(src_dir):
            src_path = os.path.join(src_dir, item)
            dst_path = os.path.join(dest_dir, item)
            if os.path.isdir(src_path):
                shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
            else:
                shutil.copy2(src_path, dst_path)

        print(f"✅ Copied entire project directory to {dest_dir}")


# Определяем расширение, которое будет собираться CMake
ext_modules = [
    CMakeExtension('libgrpp', cmake_target='liblibgrpp', sourcedir='libgrpp')
]

# Вызываем функцию setup()
setup(
    name='libgrpp',
    version='0.0.1',
    author='A. Oleynichenko, M. Losev',
    author_email='alexvoleynichenko@gmail.com, losev.mi@phystech.su',
    description='libgrpp4pyscf is a Python module that acts as a middleware between the high-performance C library libgrpp, which implements generalized relativistic pseudopotentials (GRPPs), and the PySCF package for quantum chemistry calculations. This module enables the seamless integration of precise relativistic Hamiltonians-accounting for Breit electron-electron interactions and one-loop QED corrections-into PySCF workflows. By providing a user-friendly interface for complex relativistic methods, libgrpp4pyscf allows users to bypass demanding four-component calculations while maintaining high accuracy in modeling the electronic structures of atoms, molecules, clusters, and solids.',
    long_description=readme(),
    long_description_content_type='text/markdown',
    url='https://github.com/aoleynichenko/libgrpp',
    packages=find_packages(),
    include_package_data=True,
    install_requires=['numpy', 'scipy', 'pyscf'],
    #classifiers=[""],
    keywords='libgrpp4pyscf, libgrpp, PySCF, Generalized Relativistic Pseudopotentials (GRPP), Quantum Chemistry, Relativistic Hamiltonians, Breit Electron–Electron Interactions',
    #python_requires='',
    ext_modules=ext_modules,
    cmdclass={
        'build_ext': CMakeBuild,
        'install': CustomInstallCommand
    }
)
