#
# Python interface for the LIBGRPP library.
#
# A. Oleynichenko, 2024
#

#
# more on generalized relativistic pseudopotentials (grpp):
#
# [1] N. S. Mosyagin, A. V. Titov, Z. Latajka.
# Generalized relativistic effective core potential: Gaussian expansions
# of potentials and pseudospinors for atoms Hg through Rn.
# Int. J. Quantum Chem. 63(6), 1107 (1997)
# https://doi.org/10.1002/(SICI)1097-461X(1997)63:6<1107::AID-QUA4>3.0.CO;2-0
#
# [2] A. V. Titov, N. S. Mosyagin.
# Generalized relativistic effective core potential: Theoretical grounds.
# Int. J. Quantum. Chem. 71(5), 359 (1999)
# https://doi.org/10.1002/(SICI)1097-461X(1999)71:5<359::AID-QUA1>3.0.CO;2-U
#
# [3] A. N. Petrov, N. S. Mosyagin, A. V. Titov, I. I. Tupitsyn.
# Accounting for the Breit interaction in relativistic effective core
# # potential calculations of actinides.
# J. Phys. B: At. Mol. Opt. Phys. 37, 4621 (2004)
# https://doi.org/10.1088/0953-4075/37/23/004
#
# [4] A. Zaitsevskii, N. S. Mosyagin, A. V. Oleynichenko, E. Eliav.
# Generalized relativistic small-core pseudopotentials accounting for quantum
# electrodynamic effects: Construction and pilot applications.
# Int. J. Quantum Chem. 123(8), e27077 (2023)
#
# [5] A. V. Oleynichenko, A. Zaitsevskii, N. S. Mosyagin, A. N. Petrov,
# E. Eliav, A. V. Titov.
# LIBGRPP: A Library for the Evaluation of Molecular Integrals of the Generalized
# Relativistic Pseudopotential Operator over Gaussian Functions.
# Symmetry, 15(1), 197 (2023)
# https://doi.org/10.3390/sym15010197
#