#
# python interface for the libgrpp library.
# bindings to the pyscf package
#
# a. oleynichenko, 2024
#

#
# more on generalized relativistic pseudopotentials (grpp):
#
# [1] N. S. Mosyagin, A. V. Titov, Z. Latajka.
# Generalized relativistic effective core potential: Gaussian expansions
# of potentials and pseudospinors for atoms Hg through Rn.
# Int. J. Quantum Chem. 63(6), 1107 (1997)
# https://doi.org/10.1002/(SICI)1097-461X(1997)63:6<1107::AID-QUA4>3.0.CO;2-0
#
# [2] A. V. Titov, N. S. Mosyagin.
# Generalized relativistic effective core potential: Theoretical grounds.
# Int. J. Quantum. Chem. 71(5), 359 (1999)
# https://doi.org/10.1002/(SICI)1097-461X(1999)71:5<359::AID-QUA1>3.0.CO;2-U
#
# [3] A. N. Petrov, N. S. Mosyagin, A. V. Titov, I. I. Tupitsyn.
# Accounting for the Breit interaction in relativistic effective core
# # potential calculations of actinides.
# J. Phys. B: At. Mol. Opt. Phys. 37, 4621 (2004)
# https://doi.org/10.1088/0953-4075/37/23/004
#
# [4] A. Zaitsevskii, N. S. Mosyagin, A. V. Oleynichenko, E. Eliav.
# Generalized relativistic small-core pseudopotentials accounting for quantum
# electrodynamic effects: Construction and pilot applications.
# Int. J. Quantum Chem. 123(8), e27077 (2023)
#
# [5] A. V. Oleynichenko, A. Zaitsevskii, N. S. Mosyagin, A. N. Petrov,
# E. Eliav, A. V. Titov.
# LIBGRPP: A Library for the Evaluation of Molecular Integrals of the Generalized
# Relativistic Pseudopotential Operator over Gaussian Functions.
# Symmetry, 15(1), 197 (2023)
# https://doi.org/10.3390/sym15010197
#

import copy
import math
import re
import time

import numpy as np
from scipy.special import factorial2
import pyscf.data.elements
import pyscf.gto
from pyscf.lib import param

import libgrpp


class GRPPMole(pyscf.gto.Mole):
    """
    Data structure to represent a molecule containing generalized relativistic pseudopotentials (GRPPs)
    on atoms.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.grpps = {}
        self._use_pyscf_integrals = False
        self._semilocal_only = False
        self._point_charges = None

    def build(self, dump_input=True, parse_arg=pyscf.gto.mole.ARGPARSE,
              verbose=None, output=None, max_memory=None,
              atom=None, basis=None, unit=None, nucmod=None, ecp=None, pseudo=None,
              charge=None, spin=0, symmetry=None, symmetry_subgroup=None,
              cart=None, magmom=None, point_charges=None):

        if ecp and type(ecp) is dict:
            for element_symbol in ecp:
                if type(ecp[element_symbol]) is libgrpp.GRPP:
                    #print('GRPP for %s' % (element_symbol))
                    grpp = ecp[element_symbol]
                    nwchem_style_ecp = grpp_to_nwchem_format(grpp)
                    ecp[element_symbol] = pyscf.gto.parse_ecp(nwchem_style_ecp)
                    self.grpps[element_symbol] = grpp
                    #print(nwchem_style_ecp)

        mol = super().build(dump_input, parse_arg,
                            verbose, output, max_memory,
                            atom, basis, unit, nucmod, ecp, pseudo,
                            charge, spin, symmetry, symmetry_subgroup,
                            cart, magmom)

        if mol.has_ecp():
            for element_symbol in mol.ecp.keys():
                if element_symbol not in self.grpps:
                    self.grpps[element_symbol] = grpp_from_pyscf_ecp_format(mol, element_symbol)

        if point_charges:
            self._point_charges = np.array(copy.deepcopy(point_charges), dtype=np.float64)

            # conversion from angstroms to bohrs (if needed)
            if unit in ['A', 'a', 'Angstrom', 'angstrom', 'Ang', 'ang']:
                self._point_charges[:, :3] /= param.BOHR

        # for element in self.grpps.keys():
        #    print('element = ', element)
        #    print(self.grpps[element])

        return mol

    def energy_nuc(self):
        """
        Coulomb nuclear repulsion energy (including additional point charges if needed)
        """
        if self._point_charges is None:
            return super().energy_nuc()

        charges = copy.deepcopy(self.atom_charges())
        coords = copy.deepcopy(self.atom_coords())

        # we consider charges of nuclei and point charges on an equal footing
        for i in range(0, len(self._point_charges)):
            charges = np.append(charges, [self._point_charges[i][3]])
            coords = np.vstack([coords, np.array(self._point_charges[i][:3])])

        enuc = 0.0
        for i in range(0, len(charges)):
            for j in range(i + 1, len(charges)):
                r_ij = np.linalg.norm(coords[i] - coords[j])
                if r_ij < 1e-5:
                    continue
                enuc += charges[i] * charges[j] / r_ij

        return enuc

    def use_pyscf_integrals(self):
        self._use_pyscf_integrals = True

    def use_libgrpp_integrals(self):
        self._use_pyscf_integrals = False

    def calculate_semilocal_only(self):
        self._semilocal_only = True

    def calculate_full_grpp(self):
        self._semilocal_only = False

    def intor(self, integrals_type, comp=None, hermi=0, aosym='s1', out=None,
              shls_slice=None, grids=None):

        #print('GRPP.intor(%s)' % integrals_type)
        libgrpp.init()

        if self._use_pyscf_integrals and integrals_type != 'int1e_nuc':
            return super().intor(integrals_type, comp, hermi, aosym, out, shls_slice, grids)

        if integrals_type == 'int1e_nuc':
            integrals_type = 'nuclear_attraction'

        if not self._semilocal_only:
            if integrals_type == 'ECPscalar':
                integrals_type = 'grpp_scalar'
            elif integrals_type == 'ECPso':
                integrals_type = 'grpp_spin_orbit'
        else:
            if integrals_type == 'ECPscalar':
                integrals_type = 'ecp_scalar'
            elif integrals_type == 'ECPso':
                integrals_type = 'ecp_spin_orbit'

        #elif integrals_type == 'ECPscalar_ipnuc':
        #    integrals_type = 'grpp_scalar_grad_bra'

        if integrals_type in ('nuclear_attraction',
                              'ecp_scalar', 'ecp_spin_orbit',
                              'grpp_scalar', 'grpp_spin_orbit', 'grpp_outercore', 'grpp_full'):
            return intor(self, integrals_type)

        return super().intor(integrals_type, comp, hermi, aosym, out, shls_slice, grids)


def intor(mol, operator_name, cart=False, point_3d=None):
    r'''One-electron integrals using LIBGRPP.

    Args:
        mol: pyscf.gto.Mole or GRPPMole.
            Data structure describing a molecule. Integrals over GRPPs are available
            for the GRPPMole objects only (the 'grpp_' prefix).
        intor : str
            Name of the 1e AO integrals. Available 1-electron integral names:
            'overlap'             overlap integrals
            'kinetic'             kinetic energy integrals
            'nuclear_attraction'  nuclear attraction integrals
            'ecp_scalar'          scalar part of ECP/GRPP (only local + semilocal terms are accounted for)
            'ecp_spin_orbit'      spin-orbit part of ECP/GRPP (only semilocal terms are accounted for)
            'grpp_scalar'         scalar part of GRPP (local + semilocal + non-local terms)
            'grpp_spin_orbit'     spin-orbit part of GRPP (semilocal + non-local terms)
            'grpp_outercore'      both scalar and spin-orbit parts, only non-local terms of GRPP
            'grpp_full'           both scalar and spin-orbit parts, all terms of GRPP
            and also their gradients:
            'overlap_grad'
            'overlap_grad_bra'
            'ecp_scalar_grad'
            'ecp_scalar_grad_bra'
            'ecp_spin_orbit_grad'
            'ecp_spin_orbit_grad_bra'
            'grpp_scalar_grad'
            'grpp_scalar_grad_bra'
            'grpp_spin_orbit_grad'
            'grpp_spin_orbit_grad_bra'
            'grpp_full_grad'
            'grpp_full_grad_bra'

    Kwargs:
        cart : boolean
            transfer to Cartesian basis if True, default - spherical basis

    Returns:
        list of ndarrays (2-dim) of 1-electron integrals,
        the number of these matrices depends on operator_name.

    Examples:

    >>> intor(mol, 'grpp_full')
    '''

    libgrpp.init()

    #
    # number of matrices to be returned:
    #
    num_matrices = 1
    if operator_name in ('ecp_spin_orbit', 'grpp_spin_orbit'):
        num_matrices = 3
    if operator_name in ('grpp_full', 'grpp_outercore'):
        num_matrices = 4
    if operator_name in ('overlap_grad', 'overlap_grad_bra',
                         'ecp_scalar_grad', 'ecp_scalar_grad_bra',
                         'grpp_scalar_grad', 'grpp_scalar_grad_bra'):
        num_matrices = 3
    if operator_name in ('ecp_spin_orbit_grad', 'ecp_spin_orbit_grad_bra',
                         'grpp_spin_orbit_grad', 'grpp_spin_orbit_grad_bra'):
        num_matrices = 9
    if operator_name == 'grpp_full_grad' or operator_name == 'grpp_full_grad_bra':
        num_matrices = 12

    shell_list = construct_list_of_shells(mol)
    potential_list, so_potential_list = construct_libgrpp_potentials(mol)
    renorm_factors = cartesian_renormalization_factors_libgrpp_to_pyscf(shell_list)
    cart_basis_dim = _cartesian_basis_dim(shell_list)
    ao_matrices_cart = np.zeros((num_matrices, cart_basis_dim, cart_basis_dim))

    if operator_name == 'overlap' or operator_name == 'kinetic' or operator_name == 'nuclear_attraction'\
            or operator_name == 'ecp_scalar' or operator_name == 'ecp_spin_orbit' or operator_name == 'grpp_full':
        #print('special case: ', operator_name)

        t1 = time.perf_counter()

        if operator_name == 'overlap':
            ao_matrices_cart[0] = np.reshape(libgrpp.overlap_integrals_matrix(shell_list), (cart_basis_dim, cart_basis_dim))
        elif operator_name == 'kinetic':
            ao_matrices_cart[0] = np.reshape(libgrpp.kinetic_energy_integrals_matrix(shell_list),
                                             (cart_basis_dim, cart_basis_dim))
        elif operator_name == 'nuclear_attraction':
            charges = copy.deepcopy(mol.atom_charges())
            coords = copy.deepcopy(mol.atom_coords(unit='B'))

            # add fractional point charges if needed
            if type(mol) == GRPPMole and mol._point_charges is not None:
                charges = np.append(charges, mol._point_charges[:, 3])
                coords = np.vstack([coords, mol._point_charges[:, :3]])

            for iatom, Z in enumerate(charges):
                ao_integrals_array = libgrpp.nuclear_attraction_integrals_point_charge_matrix(shell_list, coords[iatom], Z)
                ao_matrices_cart[0] += np.reshape(ao_integrals_array, (cart_basis_dim, cart_basis_dim))
        elif operator_name == 'ecp_scalar':
            for pot in potential_list:
                if pot.L == -1:
                    ao_matrices_cart[0] += np.reshape(libgrpp.type1_integrals_matrix(shell_list, pot), (cart_basis_dim, cart_basis_dim))
                else:
                    ao_matrices_cart[0] += np.reshape(libgrpp.type2_integrals_matrix(shell_list, pot), (cart_basis_dim, cart_basis_dim))
        elif operator_name == 'ecp_spin_orbit':
            for pot in so_potential_list:
                ao_integrals_array = libgrpp.spin_orbit_integrals_matrix(shell_list, pot)
                for ixyz in range(0, num_matrices):
                    ao_matrices_cart[ixyz] += np.reshape(ao_integrals_array[ixyz], (cart_basis_dim, cart_basis_dim))
            ao_matrices_cart *= - 1.0
        else:
            grpp_list = construct_list_of_grpps(mol)
            for grpp in grpp_list:
                ao_integrals_array = libgrpp.full_grpp_integrals_matrix(shell_list, grpp)
                for ixyz in range(0, num_matrices):
                    ao_matrices_cart[ixyz] += np.reshape(ao_integrals_array[ixyz], (cart_basis_dim, cart_basis_dim))

            ao_matrices_cart[1] *= - 1.0
            ao_matrices_cart[2] *= - 1.0
            ao_matrices_cart[3] *= - 1.0

        t2 = time.perf_counter()
        #print("time = %.3f" % (t2 - t1))

        #print('renormalization:')
        np_renorm_factors = np.reshape(np.array(renorm_factors), (cart_basis_dim, 1))

        t1 = time.perf_counter()
        for i_matrix in range(0, num_matrices):
            ao_matrices_cart[i_matrix] = ao_matrices_cart[i_matrix] * np_renorm_factors * np_renorm_factors.T

        t2 = time.perf_counter()
        #print("time = %.3f" % (t2 - t1))

        t1 = time.perf_counter()
        if cart:
            ao_matrices = ao_matrices_cart
        else:
            c2s = mol.cart2sph_coeff()
            dim_sph = c2s.shape[1]
            ao_matrices = np.zeros((num_matrices, dim_sph, dim_sph))

            for i in range(0, num_matrices):
                ao_matrices[i] = c2s.T.dot(ao_matrices_cart[i]).dot(c2s)

        t2 = time.perf_counter()
        #print("time = %.3f" % (t2 - t1))

        return ao_matrices[0] if num_matrices == 1 else ao_matrices


    #
    # construct matrix elements in the cartesian basis
    #
    offset_i = 0
    for ia, shell_A in enumerate(shell_list):

        print('%s %d/%d' % (operator_name, ia, len(shell_list)))

        offset_j = 0
        for shell_B in shell_list:

            size_A = shell_A.size()
            size_B = shell_B.size()
            ao_matrices_blocks = np.zeros((num_matrices, size_A, size_B))

            #
            # overlap integrals
            #
            if operator_name == 'overlap':
                ao_matrices_blocks[0] = np.reshape(libgrpp.overlap_integrals(shell_A, shell_B), (size_A, size_B))

            elif operator_name == 'overlap_grad' and point_3d:
                ao_integrals_array = libgrpp.overlap_integrals_gradient(shell_A, shell_B, point_3d)
                for ixyz in range(0, num_matrices):
                    ao_matrices_blocks[ixyz] = np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            elif operator_name == 'overlap_grad_bra':
                ao_integrals_array = libgrpp.overlap_integrals_gradient_bra(shell_A, shell_B)
                for ixyz in range(0, num_matrices):
                    ao_matrices_blocks[ixyz] = np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            #
            # kinetic energy
            #
            elif operator_name == 'kinetic':
                ao_matrices_blocks[0] = np.reshape(libgrpp.kinetic_energy_integrals(shell_A, shell_B), (size_A, size_B))

            #
            # nuclear attraction
            #
            elif operator_name == 'nuclear_attraction':
                charges = copy.deepcopy(mol.atom_charges())
                coords = copy.deepcopy(mol.atom_coords(unit='B'))

                # add fractional point charges if needed
                if mol._point_charges is not None:
                    charges = np.append(charges, mol._point_charges[:,3])
                    coords = np.vstack([coords, mol._point_charges[:,:3]])

                for iatom, Z in enumerate(charges):
                    ao_integrals_array = libgrpp.nuclear_attraction_integrals_point_charge(shell_A, shell_B,
                                                                                           coords[iatom], Z)
                    ao_matrices_blocks[0] += np.reshape(ao_integrals_array, (size_A, size_B))

            #
            # scalar part of the ecp (local + semilocal)
            #
            elif operator_name == 'ecp_scalar':
                for pot in potential_list:
                    if pot.L == -1:
                        ao_integrals_array = libgrpp.type1_integrals(shell_A, shell_B, pot)
                    else:
                        ao_integrals_array = libgrpp.type2_integrals(shell_A, shell_B, pot)
                    ao_matrices_blocks[0] += np.reshape(ao_integrals_array, (size_A, size_B))

            #
            # effective spin-orbit ecp operator (semilocal)
            #
            elif operator_name == 'ecp_spin_orbit':
                for pot in so_potential_list:
                    ao_integrals_array = libgrpp.spin_orbit_integrals(shell_A, shell_B, pot)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += np.reshape(ao_integrals_array[ixyz], (size_A, size_B))
                ao_matrices_blocks *= - 1.0

            #
            # true grpp operator - scalar part
            #
            elif operator_name == 'grpp_scalar':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = np.zeros((size_A * size_B))

                    if grpp.scalar_local_potential:
                        ao_integrals_array += libgrpp.type1_integrals(shell_A, shell_B, grpp.scalar_local_potential)

                    if grpp.scalar_semilocal_potentials:
                        for pot in grpp.scalar_semilocal_potentials:
                            ao_integrals_array += libgrpp.type2_integrals(shell_A, shell_B, pot)

                    ao_matrices_blocks[0] += np.reshape(ao_integrals_array, (size_A, size_B))

                    # outercore contributions
                    oc_potentials = grpp.get_outercore_potentials()
                    oc_shells = grpp.get_outercore_shells()
                    if oc_potentials and oc_shells:
                        oc_arep, _, _, _ = libgrpp.outercore_potential_integrals(shell_A, shell_B,
                                                                                 oc_potentials, oc_shells)
                        ao_matrices_blocks[0] += np.reshape(oc_arep, (size_A, size_B))

            #
            # true grpp operator - spin-orbit part
            #
            elif operator_name == 'grpp_spin_orbit':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    if grpp.spin_orbit_potentials:
                        for pot in grpp.spin_orbit_potentials:
                            factor = 2.0 / (2.0 * pot.L + 1.0)
                            ao_integrals_array = libgrpp.spin_orbit_integrals(shell_A, shell_B, pot)
                            for ixyz in range(0, num_matrices):
                                ao_matrices_blocks[ixyz] += factor * np.reshape(ao_integrals_array[ixyz],
                                                                                (size_A, size_B))

                    # outercore contributions
                    oc_potentials = grpp.get_outercore_potentials()
                    oc_shells = grpp.get_outercore_shells()
                    if oc_potentials and oc_shells:
                        oc_arep, oc_so_x, oc_so_y, oc_so_z = libgrpp.outercore_potential_integrals(shell_A,
                                                                                                   shell_B,
                                                                                                   oc_potentials,
                                                                                                   oc_shells)
                        ao_matrices_blocks[0] += np.reshape(oc_so_x, (size_A, size_B))
                        ao_matrices_blocks[1] += np.reshape(oc_so_y, (size_A, size_B))
                        ao_matrices_blocks[2] += np.reshape(oc_so_z, (size_A, size_B))

                ao_matrices_blocks *= - 1.0

            elif operator_name == 'grpp_outercore':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.outercore_potential_integrals(shell_A, shell_B,
                                                                               grpp.outercore_potentials,
                                                                               grpp.outercore_shells)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

                ao_matrices_blocks[1] *= - 1.0
                ao_matrices_blocks[2] *= - 1.0
                ao_matrices_blocks[3] *= - 1.0

            elif operator_name == 'grpp_full':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals(shell_A, shell_B, grpp)
                    #ao_integrals_array = libgrpp.full_grpp_integrals_version_2(shell_A, shell_B, grpp)

                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

                ao_matrices_blocks[1] *= - 1.0
                ao_matrices_blocks[2] *= - 1.0
                ao_matrices_blocks[3] *= - 1.0

            elif operator_name == 'ecp_scalar_grad' and point_3d:

                for pot in potential_list:
                    if pot.L == -1:
                        ao_integrals_array = libgrpp.type1_integrals_gradient(shell_A, shell_B, pot, point_3d)
                    else:
                        ao_integrals_array = libgrpp.type2_integrals_gradient(shell_A, shell_B, pot, point_3d)

                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            elif operator_name == 'ecp_scalar_grad_bra':

                for pot in potential_list:
                    if pot.L == -1:
                        ao_integrals_array = libgrpp.type1_integrals_gradient_bra(shell_A, shell_B, pot)
                    else:
                        ao_integrals_array = libgrpp.type2_integrals_gradient_bra(shell_A, shell_B, pot)

                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            elif operator_name == 'ecp_spin_orbit_grad' and point_3d:

                for pot in so_potential_list:
                    ao_integrals_array = libgrpp.spin_orbit_integrals_gradient(shell_A, shell_B, pot, point_3d)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += np.reshape(ao_integrals_array[ixyz], (size_A, size_B))
                ao_matrices_blocks *= - 1.0

            elif operator_name == 'ecp_spin_orbit_grad_bra':

                for pot in so_potential_list:
                    ao_integrals_array = libgrpp.spin_orbit_integrals_gradient_bra(shell_A, shell_B, pot)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += np.reshape(ao_integrals_array[ixyz], (size_A, size_B))
                ao_matrices_blocks *= - 1.0

            elif operator_name == 'grpp_scalar_grad' and point_3d:

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            elif operator_name == 'grpp_scalar_grad_bra':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            elif operator_name == 'grpp_spin_orbit_grad' and point_3d:

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz + 3], (size_A, size_B))

            elif operator_name == 'grpp_spin_orbit_grad_bra':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz + 3], (size_A, size_B))

            elif operator_name == 'grpp_full_grad' and point_3d:

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            elif operator_name == 'grpp_full_grad_bra':

                grpp_list = construct_list_of_grpps(mol)
                for grpp in grpp_list:
                    ao_integrals_array = libgrpp.full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp)
                    for ixyz in range(0, num_matrices):
                        ao_matrices_blocks[ixyz] += (-1.0) * np.reshape(ao_integrals_array[ixyz], (size_A, size_B))

            else:
                raise ValueError('unknown operator in libgrpp (%s)' % operator_name)

            for i_matrix in range(0, num_matrices):
                for i in range(0, size_A):
                    for j in range(0, size_B):
                        ao_matrices_cart[i_matrix, offset_i + i, offset_j + j] = (ao_matrices_blocks[i_matrix, i, j] *
                                                                                  renorm_factors[offset_i + i] *
                                                                                  renorm_factors[offset_j + j])

            offset_j += shell_B.size()
        offset_i += shell_A.size()

    #
    # transform to the spherical basis if required and return
    #
    if cart:
        ao_matrices = ao_matrices_cart
    else:
        c2s = mol.cart2sph_coeff()
        dim_sph = c2s.shape[1]
        ao_matrices = np.zeros((num_matrices, dim_sph, dim_sph))

        for i in range(0, num_matrices):
            ao_matrices[i] = c2s.T.dot(ao_matrices_cart[i]).dot(c2s)

    return ao_matrices[0] if num_matrices == 1 else ao_matrices


def parse_grpp(string):
    r'''Parses generalized pseudopotentials (GRPPs) given in the N. S. Mosyagin's format.
    See http://www.qchem.pnpi.spb.ru/recp for the library of GRPPs.

    Args:
        string : str
            Text containing GRPP data to be parsed

    Returns:
        ndarray of 1-electron integrals, can be either 2-dim or 3-dim, depending on comp

    Examples:

    grpp = libgrpp4pyscf.parse_grpp("""
        F09qed  ************************
                9e-GRECP with accounting for Breit, Fermi nucleus and QED effects for F    by N.S.Mosyagin from 24.06.24
                Pseudospinors from the 1s^2 2s^2 2p^4 state
                  9.00000000    1    1    1    1    2    2    1
           14    1                          1S1/2
           82370.17081127680       0.8135969144899588E-004
           15109.38991715152       0.4581877580063211E-003
           4230.178664623301       0.1803474098812020E-002
           1455.191008372157       0.5762412276092617E-002
           569.8632058339858       0.1611351304879910E-001
           244.4744106970447       0.4000935929264800E-001
           112.2835318810223       0.8775772268386212E-001
           54.34128875137511       0.1658042419779550
           27.39266018479682       0.2568946887229541
           14.25345383891705       0.2956881194578694
           7.554649879020967       0.2106260111472718
           3.953455093787507       0.6775828503958591E-001
           1.703054694968532       0.5352469663893592E-002
          0.4878162254857198       0.4837505181614294E-003
            9    1    0 0.00 30.0            2S-AREP                                            1S1/2
         1   7692.562208754857      -0.1727166868761003        0.000000000000000        0.000000000000000
         1   117.8889842821754       0.5362141471259463E-001   0.000000000000000        0.000000000000000
         1   20.03021260614915       0.4794222822063432E-002   0.000000000000000        0.000000000000000
         1  0.5091382995083186       0.1166786968777034E-003   0.000000000000000        0.000000000000000
         2  0.2768668567277002      -0.1014941759243382E-003   0.000000000000000        0.000000000000000
         1   153.7525994713892        0.000000000000000        0.000000000000000       0.1668797714343029E-001
         1   7.083301233874033        0.000000000000000        0.000000000000000      -0.1251642286185373E-001
         2   40.50098258838097        0.000000000000000        0.000000000000000       0.7260554547491083E-001
         2   13.07427954383204        0.000000000000000        0.000000000000000       0.9812918632874812E-001
            8    0    0                      2P-AREP                  2P-ESOP
         1   5323.210372518191      -0.3611826974737620E-001  0.7274237603838030E-001
         1   696.1938040922612      -0.7375300750873653E-001  0.1904191726355789
         2   287.9416345073766       0.9540830809523726E-001   1.474675329607372
         2   200.3897600243653       -1.326936801390602        1.699370894665023
         2   38.64215955578233      -0.4919051337386104E-001  0.8363273649232195E-001
         2   8.939276748509482      -0.4807004441657714E-002  0.1185293720761527E-001
         2   2.446655841883430       0.5864198263616227E-003  0.1382365639229916E-002
         2  0.5009589826307945       0.2637258744103985E-003 -0.5324070770471988E-004
        """
    '''
    lines = [line.split() for line in string.splitlines(keepends=False) if line]
    grpp = libgrpp.GRPP()

    #
    # try to get element symbol and number of explicitly treated electrons
    #
    line_count = 0
    try:
        if re.match(r'[A-Za-z]+\d+', lines[0][0]):
            element_symbol = re.search(r'[A-Za-z]+', lines[0][0])[0]
            #print('element=', element_symbol)
            num_explicit_electrons = int(re.search(r'\d+', lines[0][0])[0])
            #print('nelec=', num_explicit_electrons)
            nuc_charge = pyscf.data.elements.charge(element_symbol)
            num_core_electrons = nuc_charge - num_explicit_electrons
            grpp.nelec = num_core_electrons
            grpp.element_symbol = element_symbol
        else:
            raise SyntaxError('wrong element symbol and number of explicitly treated electrons')
    except:
        raise SyntaxError('wrong element symbol and number of explicitly treated electrons')

    #
    # skip two comment lines
    #
    line_count += 3

    #
    # string describing number of L-blocks in the basis and GRPP
    #
    try:
        meta_info_line = lines[line_count]
        num_basis_blocks = int(meta_info_line[2])
        num_arep_blocks = int(meta_info_line[-3])
        num_esop_blocks = int(meta_info_line[-2])
    except:
        raise SyntaxError('wrong number of blocks in the outercore basis, averaged or effective spin-orbit potentials')

    #
    # read outercore basis
    #
    try:
        line_count += 1
        for L in range(0, num_basis_blocks):
            num_primitives = int(lines[line_count][0])
            num_contracted = int(lines[line_count][1])
            line_count += 1

            exponents = np.zeros((num_primitives))
            coefficients = np.zeros((num_contracted, num_primitives))

            for iprim in range(0, num_primitives):
                exponents[iprim] = float(lines[line_count][0])
                for icontr in range(0, num_contracted):
                    coefficients[icontr, iprim] = float(lines[line_count][icontr + 1])
                line_count += 1

            #
            # push outercore shells into the grpp object
            #
            for icontr in range(0, num_contracted):
                grpp.add_outercore_shell(libgrpp.Shell([0, 0, 0], L, coefficients[icontr].tolist(), exponents.tolist()))
    except:
        raise SyntaxError('while reading outercore basis')

    #
    # read pseudopotential part
    #
    try:
        for L in range(0, num_arep_blocks):

            num_primitives = int(lines[line_count][0])
            num_outercore_potentials = int(lines[line_count][1])
            line_count += 1

            powers = [0 for _ in range(0, num_primitives)]
            pp_data = np.zeros((3 + num_outercore_potentials, num_primitives))

            for iprim in range(0, num_primitives):
                powers[iprim] = int(lines[line_count][0])
                for ifun in range(0, 3 + num_outercore_potentials):
                    pp_data[ifun, iprim] = float(lines[line_count][ifun + 1])
                line_count += 1

            exponents = pp_data[0]
            coeffs_arep = pp_data[1]
            coeffs_esop = pp_data[2]
            coeffs_oc_pot = pp_data[3:]

            # averaged scalar-relativistic PP
            if L == num_arep_blocks - 1:
                grpp.set_scalar_local_potential(
                    libgrpp.Potential([0, 0, 0], -1, 0, powers, coeffs_arep.tolist(), exponents.tolist()))
            else:
                grpp.add_scalar_semilocal_potential(
                    libgrpp.Potential([0, 0, 0], L, 0, powers, coeffs_arep.tolist(), exponents.tolist()))

            # effective SO operator
            if np.any(coeffs_esop):
                grpp.add_spin_orbit_potential(
                    libgrpp.Potential([0, 0, 0], L, 0, powers, coeffs_esop.tolist(), exponents.tolist()))

            # outercore potentials
            for ioc in range(0, num_outercore_potentials):
                if L == 0 or ioc % 2 != 0:
                    J = 2 * L + 1
                else:
                    J = 2 * L - 1
                grpp.add_outercore_potential(
                    libgrpp.Potential([0, 0, 0], L, J, powers, coeffs_oc_pot[ioc].tolist(), exponents.tolist()))
    except:
        raise SyntaxError('while reading pseudopotentials')

    return grpp


def load_grpp(path, label):
    r'''Reads a generalized pseudopotential with a given label from the file
    containing a set of GRPPs in the N. S. Mosyagin's format.
    '''
    extracted_grpp = ''

    with open(path, 'r', encoding='UTF-8') as file:
        while line := file.readline():
            if re.match(r'^[A-Za-z]+\d+.*\*+', line):
                label_found = line.split()[0]

                if label_found == label:
                    extracted_grpp += line

                    while line2 := file.readline():
                        if '****' in line2:
                            break
                        else:
                            extracted_grpp += line2

                    return parse_grpp(extracted_grpp)


def grpp_to_nwchem_format(grpp):
    string = ''
    string += grpp.element_symbol + ' nelec ' + str(grpp.nelec) + '\n'

    #
    # local part of the averaged potential
    #
    U_L = grpp.get_scalar_local_potential()
    string += grpp.element_symbol + ' ul\n'
    if U_L:
        for i in range(0, len(U_L.powers)):
            string += '%4d%24.16e%24.16e\n' % (U_L.powers[i], U_L.exponents[i], U_L.coeffs[i])
    else:
        string += '%4d%24.16e%24.16e\n' % (2, 1.0, 0.0)

    #
    # semilocal part: averaged potential + effective spin-orbit integraction
    #
    arep_potentials = grpp.get_scalar_semilocal_potentials()
    esop_potentials = grpp.get_spin_orbit_potentials()

    for L in range(0, 10):
        pot_arep = None
        pot_esop = None
        for pot in arep_potentials:
            if pot.L == L:
                pot_arep = pot
        if esop_potentials:
            for pot in esop_potentials:
                if pot.L == L:
                    pot_esop = pot

        if not pot_arep and not pot_esop:
            continue

        if pot_arep or pot_esop:
            string += '%s %s\n' % (grpp.element_symbol, _angular_momentum_to_str(L))

        if pot_arep and not pot_esop:
            for i in range(0, pot_arep.num_primitives):
                string += '%4d%24.16e%24.16e\n' % (pot_arep.powers[i], pot_arep.exponents[i], pot_arep.coeffs[i])

        if pot_arep and pot_esop:
            for i in range(0, pot_arep.num_primitives):
                string += '%4d%24.16e%24.16e%24.16e\n' % (
                    pot_arep.powers[i], pot_arep.exponents[i], pot_arep.coeffs[i],
                    (2.0 / (2.0 * L + 1.0)) * pot_esop.coeffs[i])

        if not pot_arep and pot_esop:
            for i in range(0, pot_esop.num_primitives):
                string += '%4d%24.16e%24.16e%24.16e\n' % (
                    pot_esop.powers[i], pot_esop.exponents[i], 0.0, (2.0 / (2.0 * L + 1.0)) * pot_esop.coeffs[i])

    return string


def grpp_from_pyscf_ecp_format(mol, element_symbol):
    if not mol.has_ecp():
        return None

    if not element_symbol in mol.ecp.keys():
        return None

    grpp = libgrpp.GRPP()
    grpp.element_symbol = element_symbol

    pyscf_format_ecp = mol.ecp[element_symbol]
    nelec = pyscf_format_ecp[0]
    grpp.nelec = nelec
    wave_potentials = pyscf_format_ecp[1]

    for ipot, wave_potential in enumerate(wave_potentials):
        L = wave_potential[0]
        wave_potential = wave_potential[1]

        powers = []
        exponents = []
        coeffs = []
        coeffs_so = []

        for npower in range(0, len(wave_potential)):
            if not wave_potential[npower]:
                continue
            for i in range(0, len(wave_potential[npower])):
                powers.append(npower)
                exponents.append(wave_potential[npower][i][0])
                coeffs.append(wave_potential[npower][i][1])
                if len(wave_potential[npower][i]) > 2:
                    coeffs_so.append(wave_potential[npower][i][2])

        if len(powers) == 0:
            continue

        if L == -1:
            grpp.set_scalar_local_potential(libgrpp.Potential([0, 0, 0], L, 0, powers, coeffs, exponents))
        else:
            grpp.add_scalar_semilocal_potential(libgrpp.Potential([0, 0, 0], L, 0, powers, coeffs, exponents))

        if len(coeffs_so) > 0:
            grpp.add_spin_orbit_potential(libgrpp.Potential([0, 0, 0], L, 0, powers, coeffs_so, exponents))

    return grpp


def parse_point_charges(string):
    lines = [line.split() for line in string.splitlines(keepends=False) if line.rstrip()]

    point_charges = []

    try:
        for line in lines:
            point_charges.append([float(line[i]) for i in range(0,4)])
    except:
        raise SyntaxError('while reading point charges. expected format: <x> <y> <z> <q>')

    return point_charges


def get_hcore_full_grpp(mol):
    h = mol.intor_symmetric('int1e_kin')

    if mol._pseudo:
        # Although mol._pseudo for GTH PP is only available in Cell, GTH PP
        # may exist if mol is converted from cell object.
        from pyscf.gto import pp_int
        h += pp_int.get_gth_pp(mol)
    else:
        h += mol.intor_symmetric('int1e_nuc')

    if len(mol._ecpbas) > 0:
        # h += mol.intor_symmetric('ECPscalar')
        h += intor(mol, 'grpp_scalar', cart=False)

    return h


def get_hcore_semilocal(mol):
    h = mol.intor_symmetric('int1e_kin')

    if mol._pseudo:
        # Although mol._pseudo for GTH PP is only available in Cell, GTH PP
        # may exist if mol is converted from cell object.
        from pyscf.gto import pp_int
        h += pp_int.get_gth_pp(mol)
    else:
        h += mol.intor_symmetric('int1e_nuc')

    if len(mol._ecpbas) > 0:
        # h += mol.intor_symmetric('ECPscalar')
        h += intor(mol, 'ecp_scalar', cart=False)

    return h


def construct_list_of_shells(mol, verbose=False):
    # extract basis functions from the Mole object
    basis_functions = {}

    for element_symbol in mol._basis.keys():
        functions_for_element = mol._basis[element_symbol]

        for fun in functions_for_element:
            L = fun[0]
            num_contracted = len(fun[1]) - 1

            for i_contracted in range(1, num_contracted + 1):
                exponents = [fun[i][0] for i in range(1, len(fun))]
                coeffs = [fun[i][i_contracted] for i in range(1, len(fun))]

                # print('%s   %d' % (element, L))
                # for i in range(0,len(exponents)):
                #    print('%20.12f%20.12f' % (exponents[i], coeffs[i]))

                # put contracted basis function
                if element_symbol not in basis_functions:
                    basis_functions[element_symbol] = []
                basis_functions[element_symbol].append((L, exponents, coeffs))

    # construct atom-centered shells
    shell_list = []

    for atm_id in range(0, mol.natm):
        symbol = mol.atom_symbol(atm_id)
        coords = mol.atom_coords('B')[atm_id]
        for fun in basis_functions[symbol]:
            sh = libgrpp.Shell(coords, fun[0], fun[2], fun[1])
            shell_list.append(sh)

    if verbose:
        for i, sh in enumerate(shell_list):
            print(i, sh)

    return shell_list


def construct_libgrpp_potentials(mol, verbose=False):
    ecp_potentials = {}
    so_ecp_potentials = {}

    if not mol.has_ecp():
        return [], []

    for element_symbol in mol.ecp:
        pyscf_format_ecp = mol.ecp[element_symbol]
        nelec = pyscf_format_ecp[0]
        wave_potentials = pyscf_format_ecp[1]

        for ipot, wave_potential in enumerate(wave_potentials):
            L = wave_potential[0]
            wave_potential = wave_potential[1]

            powers = []
            exponents = []
            coeffs = []
            coeffs_so = []

            for npower in range(0, len(wave_potential)):
                if not wave_potential[npower]:
                    continue
                for i in range(0, len(wave_potential[npower])):
                    powers.append(npower)
                    exponents.append(wave_potential[npower][i][0])
                    coeffs.append(wave_potential[npower][i][1])
                    if len(wave_potential[npower][i]) > 2:
                        coeffs_so.append(wave_potential[npower][i][2])

            if element_symbol not in ecp_potentials:
                ecp_potentials[element_symbol] = []

            if element_symbol not in so_ecp_potentials:
                so_ecp_potentials[element_symbol] = []

            if len(powers) > 0:
                ecp_potentials[element_symbol].append((L, powers, exponents, coeffs))
                if len(coeffs_so) > 0:
                    so_ecp_potentials[element_symbol].append((L, powers, exponents, coeffs_so))

    if verbose:
        for element in ecp_potentials:
            print('averaged ecp:')
            for pot in ecp_potentials[element]:
                print('%s    L=%d' % (element, pot[0]))
                for i in range(0, len(pot[1])):
                    print('  %2d%20.12f%20.12f' % (pot[1][i], pot[2][i], pot[3][i]))
            print('spin-orbit ecp:')
            for pot in so_ecp_potentials[element]:
                print('%s    L=%d' % (element, pot[0]))
                for i in range(0, len(pot[1])):
                    print('  %2d%20.12f%20.12f' % (pot[1][i], pot[2][i], pot[3][i]))

    # bind pseudopotentials to the corresponding atoms
    potential_list = []
    so_potential_list = []

    # loop over atoms with pseudopotentials
    for iatom in range(0, mol.natm):
        element_symbol = mol.atom_symbol(iatom)
        coords = mol.atom_coord(iatom, unit='B')

        if element_symbol not in ecp_potentials.keys():
            continue

        if ecp_potentials[element_symbol]:
            for pot in ecp_potentials[element_symbol]:
                libgrpp_pot = libgrpp.Potential(coords, pot[0], 0, pot[1], pot[3], pot[2])
                potential_list.append(libgrpp_pot)

        if so_ecp_potentials[element_symbol]:
            for pot in so_ecp_potentials[element_symbol]:
                libgrpp_pot = libgrpp.Potential(coords, pot[0], 0, pot[1], pot[3], pot[2])
                so_potential_list.append(libgrpp_pot)

    if verbose:
        print('arep:')
        for i, pot in enumerate(potential_list):
            print(i, pot)
        print('so:')
        for i, pot in enumerate(so_potential_list):
            print(i, pot)

    return potential_list, so_potential_list


def construct_list_of_grpps(mol):
    grpp_list = []

    assert type(mol) is GRPPMole, 'grpp integrals are available for the GRPPMole objects only'

    # loop over atoms with pseudopotentials
    for iatom in range(0, mol.natm):
        element_symbol = mol.atom_symbol(iatom)
        coords = mol.atom_coord(iatom, unit='B')

        if element_symbol not in mol.grpps.keys():
            continue

        grpp_template = mol.grpps[element_symbol]
        if grpp_template:
            grpp = copy.deepcopy(grpp_template)
            grpp.set_origin(coords)
            grpp_list.append(grpp)

    return grpp_list


def compare_integrals_with_pyscf(mol, verbose=False, gradients=True):

    #
    # get pyscf versions of matrices
    #
    if type(mol) == GRPPMole:
        mol.use_pyscf_integrals()

    if verbose:
        print('pyscf integrals:')

    t1 = time.perf_counter()
    S_pyscf = mol.intor('int1e_ovlp_sph')
    if verbose:
        print('> overlap done')

    t2 = time.perf_counter()
    T_pyscf = mol.intor('int1e_kin_sph')
    if verbose:
        print('> kinetic done')

    t3 = time.perf_counter()
    Ven_pyscf = mol.intor('int1e_nuc_sph')
    if verbose:
        print('> nuclear attraction done')

    t4 = time.perf_counter()
    AREP_pyscf = mol.intor('ECPscalar')
    if verbose:
        print('> ecp scalar done')

    t5 = time.perf_counter()
    SO_pyscf = mol.intor('ECPso')
    if verbose:
        print('> ecp spin-orbit done')

    t6 = time.perf_counter()
    if gradients:
        AREP_grad_pyscf = mol.intor('ECPscalar_ipnuc')
        if verbose:
            print('> ecp scalar gradients done')

    time_S_pyscf = t2 - t1
    time_T_pyscf = t3 - t2
    time_Ven_pyscf = t4 - t3
    time_AREP_pyscf = t5 - t4
    time_SO_pyscf = t6 - t5
    time_AREP_grad_pyscf = time.perf_counter() - t6

    if type(mol) == GRPPMole:
        mol.use_libgrpp_integrals()

    #
    # get libgrpp versions of matrices
    #
    if verbose:
        print('libgrpp integrals:')

    t1 = time.perf_counter()
    S_libgrpp = intor(mol, 'overlap', cart=False)
    if verbose:
        print('> overlap done')

    t2 = time.perf_counter()
    T_libgrpp = intor(mol, 'kinetic', cart=False)
    if verbose:
        print('> kinetic done')

    t3 = time.perf_counter()
    Ven_libgrpp = intor(mol, 'nuclear_attraction', cart=False)
    if verbose:
        print('> nuclear attraction done')

    t4 = time.perf_counter()
    AREP_libgrpp = intor(mol, 'ecp_scalar', cart=False)
    if verbose:
        print('> ecp scalar done')

    t5 = time.perf_counter()
    SO_libgrpp = intor(mol, 'ecp_spin_orbit', cart=False)
    if verbose:
        print('> ecp spin-orbit done')

    t6 = time.perf_counter()
    if gradients:
        AREP_grad_libgrpp = intor(mol, 'ecp_scalar_grad_bra', cart=False)
        if verbose:
            print('> ecp scalar gradients done')

    time_S_libgrpp = t2 - t1
    time_T_libgrpp = t3 - t2
    time_Ven_libgrpp = t4 - t3
    time_AREP_libgrpp = t5 - t4
    time_SO_libgrpp = t6 - t5
    time_AREP_grad_libgrpp = time.perf_counter() - t6

    #
    # compare: pyscf vs libgrpp
    #
    diff_S = abs((S_pyscf - S_libgrpp).max())
    diff_T = abs((T_pyscf - T_libgrpp).max())
    diff_Ven = abs((Ven_pyscf - Ven_libgrpp).max())
    diff_AREP = abs((AREP_pyscf - AREP_libgrpp).max())
    diff_SO_x = abs((SO_pyscf[0] - SO_libgrpp[0]).max())
    diff_SO_y = abs((SO_pyscf[1] - SO_libgrpp[1]).max())
    diff_SO_z = abs((SO_pyscf[2] - SO_libgrpp[2]).max())
    if gradients:
        diff_AREP_grad_x = abs((AREP_grad_pyscf[0] - AREP_grad_libgrpp[0]).max())
        diff_AREP_grad_y = abs((AREP_grad_pyscf[1] - AREP_grad_libgrpp[1]).max())
        diff_AREP_grad_z = abs((AREP_grad_pyscf[2] - AREP_grad_libgrpp[2]).max())

    #
    # print results
    #
    print('number of aos = ', S_pyscf.shape[0])
    print('-------------------------------------------------------------------')
    print('integrals               max abs diff       pyscf,sec   libgrpp,sec')
    print('-------------------------------------------------------------------')
    print('overlap               %16.8e%14.3f%14.3f' % (diff_S, time_S_pyscf, time_S_libgrpp))
    print('kinetic energy        %16.8e%14.3f%14.3f' % (diff_T, time_T_pyscf, time_T_libgrpp))
    print('nuclear attraction    %16.8e%14.3f%14.3f' % (diff_Ven, time_Ven_pyscf, time_Ven_libgrpp))
    print('scalar-rel ecp        %16.8e%14.3f%14.3f' % (diff_AREP, time_AREP_pyscf, time_AREP_libgrpp))
    print('spin-orbit ecp (x)    %16.8e%14.3f%14.3f' % (diff_SO_x, time_SO_pyscf, time_SO_libgrpp))
    print('spin-orbit ecp (y)    %16.8e%14s%14s' % (diff_SO_y, '--', '--'))
    print('spin-orbit ecp (z)    %16.8e%14s%14s' % (diff_SO_z, '--', '--'))
    if gradients:
        print('scal-rel grad (x)     %16.8e%14.3f%14.3f' % (diff_AREP_grad_x, time_AREP_grad_pyscf, time_AREP_grad_libgrpp))
        print('scal-rel grad (y)     %16.8e%14s%14s' % (diff_AREP_grad_y, '--', '--'))
        print('scal-rel grad (z)     %16.8e%14s%14s' % (diff_AREP_grad_z, '--', '--'))


def cartesian_renormalization_factors_libgrpp_to_pyscf(shell_list):
    renorm_factors = []

    def dfac(n):
        return 1 if n < 0 else factorial2(n)

    # construct matrix elements in the cartesian basis
    for shell in shell_list:

        L = shell.L
        size = shell.size()
        cart_components = shell.cartesian_components()

        S = np.reshape(libgrpp.overlap_integrals(shell, shell), (size, size))

        for i in range(0, size):
            lx, ly, lz = cart_components[i]
            factor = 1.0 / math.sqrt(S[i, i])
            factor /= 1.0 if L < 2 else 1.0 / math.sqrt(4 * math.pi / (2 * L + 1))
            factor /= math.sqrt(dfac(2 * L - 1)) / math.sqrt(dfac(2 * lx - 1) * dfac(2 * ly - 1) * dfac(2 * lz - 1))
            # factor /= 1.0 / math.sqrt(dfac(2 * lx - 1) * dfac(2 * ly - 1) * dfac(2 * lz - 1))

            renorm_factors.append(factor)

    return renorm_factors


def _cartesian_basis_dim(shell_list):
    bas_dim = 0
    for sh in shell_list:
        bas_dim += sh.size()
    return bas_dim


def _spherical_basis_dim(shell_list):
    bas_dim = 0
    for sh in shell_list:
        bas_dim += 2 * sh.L + 1
    return bas_dim


def _angular_momentum_to_str(L):
    return 'SPDFGHIKLMN'[L]
