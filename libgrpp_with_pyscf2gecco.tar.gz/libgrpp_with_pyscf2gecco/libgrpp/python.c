/*
 *  libgrpp - a library for the evaluation of integrals over
 *            generalized relativistic pseudopotentials.
 *
 *  Copyright (C) 2021-2024 Alexander Oleynichenko
 */

/*
 * Wrappers for the LIBGRPP subroutines to be used from Python projects.
 */

#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

#include "factorial.h"
#include "libgrpp.h"
#include "overlap_gradient.h"


/**
 * Analytic calculation of gradients of overlap integrals for a given shell pair
 * with respect to the point 'point_3d'.
 */
void libgrpp_overlap_integrals_gradient_python(
    libgrpp_shell_t *shell_A,
    libgrpp_shell_t *shell_B,
    double *point_3d,
    double *grad_x,
    double *grad_y,
    double *grad_z
)
{
    double *grad[3];

    grad[0] = grad_x;
    grad[1] = grad_y;
    grad[2] = grad_z;

    libgrpp_overlap_integrals_gradient(shell_A, shell_B, point_3d, grad);
}


/**
 * Analytic calculation of gradients of overlap integrals of type
 * < nabla A | B >
 */
void libgrpp_overlap_integrals_gradient_bra_python(
    libgrpp_shell_t *shell_A,
    libgrpp_shell_t *shell_B,
    double *grad_x,
    double *grad_y,
    double *grad_z
)
{
    double *grad[3];

    grad[0] = grad_x;
    grad[1] = grad_y;
    grad[2] = grad_z;

    libgrpp_overlap_integrals_gradient_bra(shell_A, shell_B, grad);
}


void libgrpp_full_grpp_integrals_gradient_python(
    libgrpp_shell_t *shell_A,
    libgrpp_shell_t *shell_B,
    libgrpp_grpp_t *grpp_operator,
    double *grpp_origin,
    double *point_3d,
    double *grad_x_arep,
    double *grad_y_arep,
    double *grad_z_arep,
    double *grad_x_so_x,
    double *grad_y_so_x,
    double *grad_z_so_x,
    double *grad_x_so_y,
    double *grad_y_so_y,
    double *grad_z_so_y,
    double *grad_x_so_z,
    double *grad_y_so_z,
    double *grad_z_so_z
)
{
    double *grad_arep[3];
    grad_arep[0] = grad_x_arep;
    grad_arep[1] = grad_y_arep;
    grad_arep[2] = grad_z_arep;

    double *grad_so_x[3];
    grad_so_x[0] = grad_x_so_x;
    grad_so_x[1] = grad_y_so_x;
    grad_so_x[2] = grad_z_so_x;

    double *grad_so_y[3];
    grad_so_y[0] = grad_x_so_y;
    grad_so_y[1] = grad_y_so_y;
    grad_so_y[2] = grad_z_so_y;

    double *grad_so_z[3];
    grad_so_z[0] = grad_x_so_z;
    grad_so_z[1] = grad_y_so_z;
    grad_so_z[2] = grad_z_so_z;

    libgrpp_full_grpp_integrals_gradient(shell_A, shell_B, grpp_operator, grpp_origin, point_3d,
        grad_arep, grad_so_x, grad_so_y, grad_so_z
    );
}


void libgrpp_full_grpp_integrals_gradient_bra_python(
    libgrpp_shell_t *shell_A,
    libgrpp_shell_t *shell_B,
    libgrpp_grpp_t *grpp_operator,
    double *grpp_origin,
    double *grad_x_arep,
    double *grad_y_arep,
    double *grad_z_arep,
    double *grad_x_so_x,
    double *grad_y_so_x,
    double *grad_z_so_x,
    double *grad_x_so_y,
    double *grad_y_so_y,
    double *grad_z_so_y,
    double *grad_x_so_z,
    double *grad_y_so_z,
    double *grad_z_so_z
)
{
    double *grad_arep[3];
    grad_arep[0] = grad_x_arep;
    grad_arep[1] = grad_y_arep;
    grad_arep[2] = grad_z_arep;

    double *grad_so_x[3];
    grad_so_x[0] = grad_x_so_x;
    grad_so_x[1] = grad_y_so_x;
    grad_so_x[2] = grad_z_so_x;

    double *grad_so_y[3];
    grad_so_y[0] = grad_x_so_y;
    grad_so_y[1] = grad_y_so_y;
    grad_so_y[2] = grad_z_so_y;

    double *grad_so_z[3];
    grad_so_z[0] = grad_x_so_z;
    grad_so_z[1] = grad_y_so_z;
    grad_so_z[2] = grad_z_so_z;

    libgrpp_full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp_operator, grpp_origin,
        grad_arep, grad_so_x, grad_so_y, grad_so_z
    );
}


int calculate_basis_dim(libgrpp_shell_t **shell_list, int num_shells)
{
    int basis_dim = 0;

    for (int ishell = 0; ishell < num_shells; ishell++) {
        libgrpp_shell_t *shell = shell_list[ishell];
        basis_dim += libgrpp_get_shell_size(shell);
    }

    return basis_dim;
}

#define MAX_BUF 10000

double abs_time()
{
    struct timeval cur_time;
    gettimeofday(&cur_time, NULL);
    return (cur_time.tv_sec * 1000000u + cur_time.tv_usec) / 1.e6;
}

void add_block_to_matrix(int dim_1, int dim_2, double *matrix,
                         int block_dim_1, int block_dim_2, double *block,
                         int col_offset, int row_offset, double factor)
{
    for (int i = 0; i < block_dim_1; i++) {
        for (int j = 0; j < block_dim_2; j++) {
            double element = block[i * block_dim_2 + j];
            matrix[(col_offset + i) * dim_2 + (row_offset + j)] += factor * element;
        }
    }
}


int omp_get_thread_num();
int omp_get_num_threads();


/*
 * arrays used for more efficient load balancing in parallelization.
 * only the upper right triangle of a matrix will be computed (since the
 * matrix is symmetric)
 */
int *calculate_offsets(int num_shells, libgrpp_shell_t **shell_list)
{
    int *offsets = calloc(num_shells, sizeof(int));

    int ioffset = 0;
    for (int ishell = 0; ishell < num_shells; ishell++) {
        offsets[ishell] = ioffset;
        libgrpp_shell_t *bra = shell_list[ishell];
        ioffset += libgrpp_get_shell_size(bra);
    }

    return offsets;
}


int *calculate_shell_pairs(int num_shells, libgrpp_shell_t **shell_list)
{
    int *shell_pairs = calloc(num_shells * num_shells * 2, sizeof(int));

    int n_shell_pairs = 0;
    for (int ishell = 0; ishell < num_shells; ishell++) {
        for (int jshell = ishell; jshell < num_shells; jshell++) {
            shell_pairs[2 * n_shell_pairs] = ishell;
            shell_pairs[2 * n_shell_pairs + 1] = jshell;
            n_shell_pairs++;
        }
    }

    return shell_pairs;
}


void libgrpp_overlap_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *overlap_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(overlap_matrix, 0, sizeof(double) * dim * dim);

    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*
     * only upper right triangle of a matrix will be calculated
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, overlap_matrix, num_shells, shell_list)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        double buf[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        libgrpp_overlap_integrals(bra, ket, buf);
        add_block_to_matrix(dim, dim, overlap_matrix, bra_dim, ket_dim, buf, ioffset, joffset, 1.0);
    }

    /*
     * restore the lower left triangle of a matrix
     */
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < i; j++) {
            overlap_matrix[i * dim + j] = overlap_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}


void libgrpp_kinetic_energy_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *kinetic_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(kinetic_matrix, 0, sizeof(double) * dim * dim);

    /*
     * arrays used for more efficient load balancing in parallelization.
     * only the upper right triangle of a matrix will be computed (since the
     * matrix is symmetric)
     */
    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*
     * openmp parallelization
     * to test thread-safety of libgrpp
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, kinetic_matrix, num_shells, shell_list)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        double buf[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        libgrpp_kinetic_energy_integrals(bra, ket, buf);
        add_block_to_matrix(dim, dim, kinetic_matrix, bra_dim, ket_dim, buf, ioffset, joffset, 1.0);
    }

    /*
     * restore the lower left triangle of a matrix
     */
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < i; j++) {
            kinetic_matrix[i * dim + j] = kinetic_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}


void libgrpp_nuclear_attraction_integrals_point_charge_matrix(int num_shells, libgrpp_shell_t **shell_list, double *charge_origin,
    double charge, double *v_en_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(v_en_matrix, 0, sizeof(double) * dim * dim);

    /*
     * arrays used for more efficient load balancing in parallelization.
     * only the upper right triangle of a matrix will be computed (since the
     * matrix is symmetric)
     */
    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*
     * openmp parallelization
     * to test thread-safety of libgrpp
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, v_en_matrix, num_shells, shell_list, charge_origin, charge)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        double buf[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        libgrpp_nuclear_attraction_integrals_point_charge(bra, ket, charge_origin, 1, buf);
        add_block_to_matrix(dim, dim, v_en_matrix, bra_dim, ket_dim, buf, ioffset, joffset, charge);
    }

    /*
     * restore the lower left triangle of a matrix
     */
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < i; j++) {
            v_en_matrix[i * dim + j] = v_en_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}


void libgrpp_type1_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *rpp_origin,
    libgrpp_potential_t *potential, double *arep_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(arep_matrix, 0, sizeof(double) * dim * dim);

    /*
     * arrays used for more efficient load balancing in parallelization.
     * only the upper right triangle of a matrix will be computed (since the
     * matrix is symmetric)
     */
    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*
     * openmp parallelization
     * to test thread-safety of libgrpp
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, arep_matrix, num_shells, shell_list, rpp_origin, potential)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        double buf[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        libgrpp_type1_integrals(bra, ket, rpp_origin, potential, buf);
        add_block_to_matrix(dim, dim, arep_matrix, bra_dim, ket_dim, buf, ioffset, joffset, 1.0);
    }

    /*
     * restore the lower left triangle of a matrix
     */
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < i; j++) {
            arep_matrix[i * dim + j] = arep_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}

typedef struct {
    int ishell;
    int jshell;
    libgrpp_shell_t **shell_list;
} shell_pair_t;


int compare_pairs(const void* a, const void* b) {
    shell_pair_t *pair_a = (shell_pair_t *) a;
    shell_pair_t *pair_b = (shell_pair_t *) b;

    // calculate overall angular momentum
    libgrpp_shell_t **shell_list = pair_a->shell_list;

    int Lsum_a = shell_list[pair_a->ishell]->L + shell_list[pair_a->jshell]->L;
    int Lsum_b = shell_list[pair_b->ishell]->L + shell_list[pair_b->jshell]->L;

    return Lsum_b - Lsum_a;
}


void libgrpp_type2_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *rpp_origin,
    libgrpp_potential_t *potential, double *arep_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(arep_matrix, 0, sizeof(double) * dim * dim);

    /*
     * arrays used for more efficient load balancing in parallelization.
     * only the upper right triangle of a matrix will be computed (since the
     * matrix is symmetric)
     */
    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*shell_pair_t *pairs = calloc(n_shell_pairs, sizeof(shell_pair_t));
    for (int i = 0; i < n_shell_pairs; i++) {
        pairs[i].ishell = shell_pairs[2 * i];
        pairs[i].jshell = shell_pairs[2 * i + 1];
        pairs[i].shell_list = shell_list;
    }

    qsort(pairs, n_shell_pairs, sizeof(shell_pair_t), compare_pairs);*/

    /*
     * openmp parallelization
     * to test thread-safety of libgrpp
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, arep_matrix, num_shells, shell_list, rpp_origin, potential)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        //if (ipair % 1000 == 0) printf("%d/%d\n", ipair, n_shell_pairs);

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        //int ishell = pairs[ipair].ishell;
        //int jshell = pairs[ipair].jshell;
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        //printf("%d - %d  ", ishell, jshell);

        double buf[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        //printf("   L = %d - %d      sumL = %d\n", bra->L, ket->L, bra->L + ket->L);

        libgrpp_type2_integrals(bra, ket, rpp_origin, potential, buf);
        add_block_to_matrix(dim, dim, arep_matrix, bra_dim, ket_dim, buf, ioffset, joffset, 1.0);
    }

    /*
     * restore the lower left triangle of a matrix
     */
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < i; j++) {
            arep_matrix[i * dim + j] = arep_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}


void libgrpp_spin_orbit_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *rpp_origin,
    libgrpp_potential_t *potential, double *so_x_matrix, double *so_y_matrix, double *so_z_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(so_x_matrix, 0, sizeof(double) * dim * dim);
    memset(so_y_matrix, 0, sizeof(double) * dim * dim);
    memset(so_z_matrix, 0, sizeof(double) * dim * dim);

    /*
     * arrays used for more efficient load balancing in parallelization.
     * only the upper right triangle of a matrix will be computed (since the
     * matrix is symmetric)
     */
    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*
     * openmp parallelization
     * to test thread-safety of libgrpp
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, num_shells, shell_list, rpp_origin, potential, \
    so_x_matrix, so_y_matrix, so_z_matrix)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        double buf_x[MAX_BUF];
        double buf_y[MAX_BUF];
        double buf_z[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        libgrpp_spin_orbit_integrals(bra, ket, rpp_origin, potential, buf_x, buf_y, buf_z);

        add_block_to_matrix(dim, dim, so_x_matrix, bra_dim, ket_dim, buf_x, ioffset, joffset, 1.0);
        add_block_to_matrix(dim, dim, so_y_matrix, bra_dim, ket_dim, buf_y, ioffset, joffset, 1.0);
        add_block_to_matrix(dim, dim, so_z_matrix, bra_dim, ket_dim, buf_z, ioffset, joffset, 1.0);
    }

    /*
     * restore the lower left triangle of a matrix
     */
    for (int i = 0; i < dim; i++) {
        so_x_matrix[i * dim + i] = 0.0;
        so_y_matrix[i * dim + i] = 0.0;
        so_z_matrix[i * dim + i] = 0.0;

        for (int j = 0; j < i; j++) {
            so_x_matrix[i * dim + j] = - so_x_matrix[j * dim + i];
            so_y_matrix[i * dim + j] = - so_y_matrix[j * dim + i];
            so_z_matrix[i * dim + j] = - so_z_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}

/*
void libgrpp_full_grpp_integrals(
    libgrpp_shell_t *shell_A,
    libgrpp_shell_t *shell_B,
    libgrpp_grpp_t *grpp_operator,
    double *grpp_origin,
    double *arep_matrix,
    double *so_x_matrix,
    double *so_y_matrix,
    double *so_z_matrix
)
*/

void libgrpp_full_grpp_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list,
    libgrpp_grpp_t *grpp_operator, double *rpp_origin,
    double *arep_matrix, double *so_x_matrix, double *so_y_matrix, double *so_z_matrix)
{
    int dim = calculate_basis_dim(shell_list, num_shells);
    memset(arep_matrix, 0, sizeof(double) * dim * dim);
    memset(so_x_matrix, 0, sizeof(double) * dim * dim);
    memset(so_y_matrix, 0, sizeof(double) * dim * dim);
    memset(so_z_matrix, 0, sizeof(double) * dim * dim);

    /*
     * arrays used for more efficient load balancing in parallelization.
     * only the upper right triangle of a matrix will be computed (since the
     * matrix is symmetric)
     */
    int *offsets = calculate_offsets(num_shells, shell_list);
    int *shell_pairs = calculate_shell_pairs(num_shells, shell_list);
    int n_shell_pairs = num_shells * (num_shells + 1) / 2;

    /*
     * openmp parallelization
     * to test thread-safety of libgrpp
     */
#pragma omp parallel for schedule(dynamic) \
    default(none) \
    shared(shell_pairs, n_shell_pairs, offsets, dim, num_shells, shell_list, rpp_origin, grpp_operator, \
    arep_matrix, so_x_matrix, so_y_matrix, so_z_matrix)
    for (int ipair = 0; ipair < n_shell_pairs; ipair++) {

        int ishell = shell_pairs[2 * ipair];
        int jshell = shell_pairs[2 * ipair + 1];
        int ioffset = offsets[ishell];
        int joffset = offsets[jshell];

        double buf_a[MAX_BUF];
        double buf_x[MAX_BUF];
        double buf_y[MAX_BUF];
        double buf_z[MAX_BUF];

        libgrpp_shell_t *bra = shell_list[ishell];
        int bra_dim = libgrpp_get_shell_size(bra);

        libgrpp_shell_t *ket = shell_list[jshell];
        int ket_dim = libgrpp_get_shell_size(ket);

        libgrpp_full_grpp_integrals(bra, ket, grpp_operator, rpp_origin, buf_a, buf_x, buf_y, buf_z);

        add_block_to_matrix(dim, dim, arep_matrix, bra_dim, ket_dim, buf_a, ioffset, joffset, 1.0);
        add_block_to_matrix(dim, dim, so_x_matrix, bra_dim, ket_dim, buf_x, ioffset, joffset, 1.0);
        add_block_to_matrix(dim, dim, so_y_matrix, bra_dim, ket_dim, buf_y, ioffset, joffset, 1.0);
        add_block_to_matrix(dim, dim, so_z_matrix, bra_dim, ket_dim, buf_z, ioffset, joffset, 1.0);
    }

    /*
     * restore the lower left triangle of matrices:
     * arep: symmetric matrix
     * so: anti-symmetric matrices
     */
    for (int i = 0; i < dim; i++) {
        so_x_matrix[i * dim + i] = 0.0;
        so_y_matrix[i * dim + i] = 0.0;
        so_z_matrix[i * dim + i] = 0.0;

        for (int j = 0; j < i; j++) {
            arep_matrix[i * dim + j] = arep_matrix[j * dim + i];
            so_x_matrix[i * dim + j] = - so_x_matrix[j * dim + i];
            so_y_matrix[i * dim + j] = - so_y_matrix[j * dim + i];
            so_z_matrix[i * dim + j] = - so_z_matrix[j * dim + i];
        }
    }

    free(offsets);
    free(shell_pairs);
}

