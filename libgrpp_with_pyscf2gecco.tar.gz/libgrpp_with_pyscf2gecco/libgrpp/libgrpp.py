#
# Python interface for the LIBGRPP library.
#
# A. Oleynichenko, 2024
#

#
# more on generalized relativistic pseudopotentials (grpp):
#
# [1] N. S. Mosyagin, A. V. Titov, Z. Latajka.
# Generalized relativistic effective core potential: Gaussian expansions
# of potentials and pseudospinors for atoms Hg through Rn.
# Int. J. Quantum Chem. 63(6), 1107 (1997)
# https://doi.org/10.1002/(SICI)1097-461X(1997)63:6<1107::AID-QUA4>3.0.CO;2-0
#
# [2] A. V. Titov, N. S. Mosyagin.
# Generalized relativistic effective core potential: Theoretical grounds.
# Int. J. Quantum. Chem. 71(5), 359 (1999)
# https://doi.org/10.1002/(SICI)1097-461X(1999)71:5<359::AID-QUA1>3.0.CO;2-U
#
# [3] A. N. Petrov, N. S. Mosyagin, A. V. Titov, I. I. Tupitsyn.
# Accounting for the Breit interaction in relativistic effective core
# # potential calculations of actinides.
# J. Phys. B: At. Mol. Opt. Phys. 37, 4621 (2004)
# https://doi.org/10.1088/0953-4075/37/23/004
#
# [4] A. Zaitsevskii, N. S. Mosyagin, A. V. Oleynichenko, E. Eliav.
# Generalized relativistic small-core pseudopotentials accounting for quantum
# electrodynamic effects: Construction and pilot applications.
# Int. J. Quantum Chem. 123(8), e27077 (2023)
#
# [5] A. V. Oleynichenko, A. Zaitsevskii, N. S. Mosyagin, A. N. Petrov,
# E. Eliav, A. V. Titov.
# LIBGRPP: A Library for the Evaluation of Molecular Integrals of the Generalized
# Relativistic Pseudopotential Operator over Gaussian Functions.
# Symmetry, 15(1), 197 (2023)
# https://doi.org/10.3390/sym15010197
#

import platform
import copy
from ctypes import *

# #
# # get the right filename
# #
# if platform.uname()[0] == "Windows":
#     name = "libgrpp/liblibgrpp.dll"
# elif platform.uname()[0] == "Linux":
#     name = "libgrpp/liblibgrpp.so"
# else:
#     name = "libgrpp/liblibgrpp.dylib"

# #
# # load the pre-compiled dynamic library LIBGRPP
# #
# dll = cdll.LoadLibrary(name)

import os

# Get the current system name (e.g., 'Windows', 'Linux', 'Darwin')
system = platform.system()
# Define the directory where the library is stored (adjust if needed)
lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "libgrpp")

# Determine the library filename based on the platform
if system == "Windows":
    lib_filename = "liblibgrpp.dll"
elif system == "Linux":
    lib_filename = "liblibgrpp.so"
elif system == "Darwin":
    lib_filename = "liblibgrpp.dylib"
else:
    raise OSError(f"Unsupported platform: {system}")

# Construct the full path to the library
lib_path = os.path.join(lib_dir, lib_filename)

# Check if the library file exists
if not os.path.exists(lib_path):
    raise FileNotFoundError(f"Library file not found at {lib_path}")

# Load the library using ctypes
dll = cdll.LoadLibrary(lib_path)

del system, lib_filename, lib_dir


class Shell:
    """
    Structure representing a shell - a set of contracted basis functions
    with a given angular momentum L placed at some origin.
    To the moment only Cartesian shells are supported in this structure.
    """

    def __init__(self, origin, L, coeffs, exponents):
        r'''Constructs a new shell object.

        Args:
            origin : 3-element list
                3D point at which the shell is centered
            L : int
                angular momentum of the basis function
            coeffs : list
                contraction coeff -s (do not include norm factors)
            exponents: list
                exponential parameters of Gaussians primitives

        Examples:

        >>> shell = Shell([0,0,0], 2, [0.1309756377E+01, 0.2331359749E+00], [0.4301284983E+00, 0.6789135305E+00])
        '''
        if len(coeffs) != len(exponents):
            raise ValueError('different lengths of coefficient (len=%d) and exponent (len=%d) arrays' %
                             (len(coeffs), len(exponents)))

        self.origin = copy.deepcopy(origin)
        self.L = L
        self.num_primitives = len(coeffs)
        self.coeffs = copy.deepcopy(coeffs)
        self.exponents = copy.deepcopy(exponents)

    def set_origin(self, origin):
        self.origin = copy.deepcopy(origin)

    def __str__(self):
        return 'origin=' + str(self.origin) + \
            ' L=' + str(self.L) + \
            ' exponents=' + str(self.exponents) + ' coeffs=' + str(self.coeffs)

    def cartesian_components(self):
        r'''Returns list of Cartesian components of the shell
        (list of powers (n,l,m) for each Cartesian primitive).
        '''
        L = self.L
        cart_list = []

        for lx in reversed(range(L + 1)):
            for ly in reversed(range(L + 1 - lx)):
                lz = L - lx - ly

                cart_list.append((lx, ly, lz))

        return cart_list

    def size(self):
        r'''Returns number of Cartesian primitives inside the shell.
        '''
        return int((self.L + 1) * (self.L + 2) / 2)


def _create_c_shell(shell):
    r'''Returns pointer to a C object representing a shell.
    '''
    #
    # C function:
    # libgrpp_shell_t *libgrpp_new_shell(double *origin, int L, int num_primitives, double *coeffs, double *alpha);
    #
    dll.libgrpp_new_shell.argtypes = [POINTER(c_double), c_int, c_int, POINTER(c_double), POINTER(c_double)]
    dll.libgrpp_new_shell.restype = c_void_p

    c_origin_array = (c_double * 3)(*shell.origin)
    c_coeffs_array = (c_double * shell.num_primitives)(*shell.coeffs)
    c_exponents_array = (c_double * shell.num_primitives)(*shell.exponents)

    return dll.libgrpp_new_shell(c_origin_array, shell.L, shell.num_primitives, c_coeffs_array, c_exponents_array)


def _delete_c_shell(ptr_shell):
    r'''Destroys a C object representing a shell and deallocates memory for it.
    '''
    #
    # C function:
    # void libgrpp_delete_shell(libgrpp_shell_t *shell);
    #
    dll.libgrpp_delete_shell.argtypes = [c_void_p]

    dll.libgrpp_delete_shell(ptr_shell)


class Potential:
    """
    Structure representing an effective potential (only one partial wave).
    """

    def __init__(self, origin, L, J, powers, coeffs, exponents):
        r'''Constructs an object representing a pseudopotential (PP) (only one wave L,J).

        Args:
            origin : 3-element list
                3D point at which the shell is centered
            L : int
                spatial angular momentum of the PP operator
            J : int
                total angular momentum of the PP operator
            powers : list
                powers 'n' for each PP primitive r^{n-2} e^{-alpha * r^2}
            coeffs : list
                coefficients of the PP expansion
            exponents: list
                exponents of the PP expansion
        '''
        if len(powers) != len(coeffs):
            raise ValueError('different lengths of power (len=%d) and coefficient (len=%d) arrays' %
                             (len(powers), len(coeffs)))

        if len(powers) != len(exponents):
            raise ValueError('different lengths of power (len=%d) and exponent (len=%d) arrays' %
                             (len(powers), len(exponents)))

        self.origin = copy.deepcopy(origin)
        self.L = L
        self.J = J
        self.num_primitives = len(powers)
        self.powers = copy.deepcopy(powers)
        self.coeffs = copy.deepcopy(coeffs)
        self.exponents = copy.deepcopy(exponents)

    def set_origin(self, origin):
        self.origin = copy.deepcopy(origin)

    def __str__(self):
        return 'origin=' + str(self.origin) + \
            ' L=' + str(self.L) + ' J=' + str(self.J) + \
            ' powers=' + str(self.powers) + \
            ' exponents=' + str(self.exponents) + \
            ' coeffs=' + str(self.coeffs)


def _create_c_potential(potential):
    r'''Returns pointer to a C object representing a pseudopotential wave with given L,J.
    '''
    #
    # C function:
    # libgrpp_potential_t *libgrpp_new_potential(int L, int J, int num_primitives, int *powers, double *coeffs, double *alpha);
    #
    dll.libgrpp_new_potential.argtypes = [c_int, c_int, c_int, POINTER(c_int), POINTER(c_double), POINTER(c_double)]
    dll.libgrpp_new_potential.restype = c_void_p

    PowersArray = c_int * potential.num_primitives
    CoeffsArray = c_double * potential.num_primitives
    AlphaArray = c_double * potential.num_primitives
    c_pot = dll.libgrpp_new_potential(c_int(potential.L), c_int(potential.J), c_int(potential.num_primitives),
                                      PowersArray(*potential.powers),
                                      CoeffsArray(*potential.coeffs),
                                      AlphaArray(*potential.exponents))
    return c_pot


def _delete_c_potential(ptr_potential):
    r'''Destroys a C object representing a pseudopotential wave with given L,J
    and deallocates memory for it.
    '''
    #
    # C function:
    # void libgrpp_delete_potential(libgrpp_potential_t *potential);
    #
    dll.libgrpp_delete_potential.argtypes = [c_void_p]

    dll.libgrpp_delete_potential(ptr_potential)


class GRPP:
    """
    Structure representing a generalized relativistic pseudopotential (GRPP)
    placed at some origin.

    GRPP consists of three types of terms:
    - local scalar-relativistic potential (no angular projectors);
    - semi-local scalar-relativistic and spin-orbit potentials (with angular projectors);
    - non-local (outercore) potentials (multiplied by projectors onto outercore shells).
    """

    def __init__(self, origin=None):
        r'''Constructor of a GRPP object. By default, GRPP contains no potentials,
        they must be added after initialization one-by-one.

        Args:
            origin : 3-element list
                3D point at which the shell is centered
        '''
        if origin is None:
            origin = [0.0, 0.0, 0.0]

        self.element_symbol = ''
        self.nelec = 0
        self.origin = copy.deepcopy(origin)

        # local potential U_L (r)
        self.scalar_local_potential = None

        # list of scalar-relativistic difference potentials
        self.scalar_semilocal_potentials = None

        # list of effective spin-orbit potentials
        self.spin_orbit_potentials = None

        # list of outercore potentials U_{n_c ,lj}
        self.outercore_potentials = None

        # list of outercore shells (for projectors)
        self.outercore_shells = None

    def set_origin(self, origin):
        r'''Sets centering point for all potentials of the GRPP.

        Args:
            origin : 3-element list
                3D point at which the shell is centered
        '''

        self.origin = copy.deepcopy(origin)

        if self.scalar_local_potential:
            self.scalar_local_potential.set_origin(origin)

        if self.scalar_semilocal_potentials:
            for pot in self.scalar_semilocal_potentials:
                pot.set_origin(origin)

        if self.spin_orbit_potentials:
            for pot in self.spin_orbit_potentials:
                pot.set_origin(origin)

        if self.outercore_shells:
            for sh in self.outercore_shells:
                sh.set_origin(origin)

        if self.outercore_potentials:
            for pot in self.outercore_potentials:
                pot.set_origin(origin)

    def set_scalar_local_potential(self, potential):
        r'''Sets local part of the averaged (scalar) potential.

        Args:
            potential : Potential
        '''
        U_L = copy.deepcopy(potential)
        U_L.origin = copy.deepcopy(self.origin)
        self.scalar_local_potential = U_L

    def add_scalar_semilocal_potential(self, potential):
        r'''Adds semilocal averaged (scalar) potential to the GRPP.

        Args:
            potential : Potential
        '''
        if not self.scalar_semilocal_potentials:
            self.scalar_semilocal_potentials = []

        U_l = copy.deepcopy(potential)
        U_l.origin = copy.deepcopy(self.origin)

        self.scalar_semilocal_potentials.append(U_l)

    def add_spin_orbit_potential(self, potential):
        r'''Adds semilocal spin-orbit effective potential to the GRPP.

        Args:
            potential : Potential
        '''
        if not self.spin_orbit_potentials:
            self.spin_orbit_potentials = []

        U_SO_l = copy.deepcopy(potential)
        U_SO_l.origin = copy.deepcopy(self.origin)

        self.spin_orbit_potentials.append(U_SO_l)

    def add_outercore_potential(self, potential):
        r'''Adds a non-local potential U_{nlj} to the GRPP.

        Args:
            potential : Potential
        '''
        if not self.outercore_potentials:
            self.outercore_potentials = []

        U_oc_lj = copy.deepcopy(potential)
        U_oc_lj.origin = copy.deepcopy(self.origin)

        self.outercore_potentials.append(U_oc_lj)

    def add_outercore_shell(self, shell):
        r'''Adds an expansion of an outercore shell |nlj> to the GRPP.
        These functions will be used to construct projectors |nlj><nlj| of the
        non-local GRPP terms.

        Args:
            shell : Shell
        '''
        if not self.outercore_shells:
            self.outercore_shells = []

        oc_shell_lj = copy.deepcopy(shell)
        oc_shell_lj.origin = copy.deepcopy(self.origin)

        self.outercore_shells.append(copy.deepcopy(oc_shell_lj))

    def get_scalar_local_potential(self):
        return self.scalar_local_potential

    def get_scalar_semilocal_potentials(self):
        return self.scalar_semilocal_potentials

    def get_spin_orbit_potentials(self):
        return self.spin_orbit_potentials

    def get_outercore_potentials(self):
        return self.outercore_potentials

    def get_outercore_shells(self):
        return self.outercore_shells

    def __str__(self):
        string = ''

        string += 'grpp:\n'
        string += 'origin=' + str(self.origin) + '\n'

        string += 'outercore shells:\n'
        if self.outercore_shells:
            for sh in self.outercore_shells:
                string += str(sh) + '\n'
        else:
            string += '---\n'

        string += 'arep:\n'
        if self.scalar_local_potential:
            string += str(self.scalar_local_potential) + '\n'
        else:
            string += '---\n'

        if self.scalar_semilocal_potentials:
            for pot in self.scalar_semilocal_potentials:
                string += str(pot) + '\n'
        else:
            string += '---\n'

        string += 'esop:\n'
        if self.spin_orbit_potentials:
            for pot in self.spin_orbit_potentials:
                string += str(pot) + '\n'
        else:
            string += '---\n'

        string += 'outercore:\n'
        if self.outercore_potentials:
            for pot in self.outercore_potentials:
                string += str(pot) + '\n'
        else:
            string += '---\n'

        return string


def _create_c_grpp(grpp):
    r'''Returns pointer to a C object representing a generalized relativistic pseudopotential (GRPP).
    '''
    #
    # local part
    #
    if grpp.scalar_local_potential:
        c_local_potentials = _create_c_potential(grpp.scalar_local_potential)
    else:
        c_local_potentials = None

    #
    # scalar-rel semilocal part
    #
    if grpp.scalar_semilocal_potentials:
        num_averaged_potentials = len(grpp.scalar_semilocal_potentials)
        c_averaged_potentials = (c_void_p * num_averaged_potentials)()
        for i in range(0, num_averaged_potentials):
            c_averaged_potentials[i] = _create_c_potential(grpp.scalar_semilocal_potentials[i])
    else:
        num_averaged_potentials = 0
        c_averaged_potentials = None

    #
    # spin-orbit semilocal part
    #
    if grpp.spin_orbit_potentials:
        num_spin_orbit_potentials = len(grpp.spin_orbit_potentials)
        c_spin_orbit_potentials = (c_void_p * num_spin_orbit_potentials)()
        for i in range(0, num_spin_orbit_potentials):
            c_spin_orbit_potentials[i] = _create_c_potential(grpp.spin_orbit_potentials[i])
    else:
        num_spin_orbit_potentials = 0
        c_spin_orbit_potentials = None

    #
    # outercore part
    #
    if grpp.outercore_potentials:
        num_oc_potentials = len(grpp.outercore_potentials)
        c_array_oc_potentials = (c_void_p * num_oc_potentials)()
        c_array_oc_shells = (c_void_p * num_oc_potentials)()
        for i in range(0, num_oc_potentials):
            c_array_oc_potentials[i] = _create_c_potential(grpp.outercore_potentials[i])
            c_array_oc_shells[i] = _create_c_shell(grpp.outercore_shells[i])
    else:
        num_oc_potentials = 0
        c_array_oc_potentials = None
        c_array_oc_shells = None

    #
    # C function:
    # libgrpp_grpp_t *libgrpp_new_grpp_from_potentials(
    #     libgrpp_potential_t *ul,
    #     int num_averaged, libgrpp_potential_t **averaged_potentials,
    #     int num_spin_orbit, libgrpp_potential_t **spin_orbit_potentials,
    #     int num_outercore, libgrpp_shell_t **oc_shells, libgrpp_potential_t **oc_potentials);
    #
    dll.libgrpp_new_grpp_from_potentials.argtypes = [c_void_p,
                                                     c_int, POINTER(c_void_p),
                                                     c_int, POINTER(c_void_p),
                                                     c_int, POINTER(c_void_p), POINTER(c_void_p)]
    dll.libgrpp_new_grpp_from_potentials.restype = c_void_p

    c_grpp = dll.libgrpp_new_grpp_from_potentials(
        c_local_potentials,
        num_averaged_potentials, c_averaged_potentials,
        num_spin_orbit_potentials, c_spin_orbit_potentials,
        num_oc_potentials, c_array_oc_shells, c_array_oc_potentials
    )

    return c_grpp


def _delete_c_grpp(c_grpp_pointer):
    r'''Destroys a C object representing a generalized relativistic pseudopotential (GRPP)
    and deallocates memory for it.
    '''
    #
    # C function:
    # void libgrpp_delete_grpp(libgrpp_grpp_t *);
    #
    dll.libgrpp_delete_grpp.argtypes = [c_void_p]

    dll.libgrpp_delete_grpp(c_grpp_pointer)


def init():
    r'''Initialization of the LIBGRPP library.
    Initialization is needed to perform some pre-tabulations in a thread-safe manner.
    '''
    dll.libgrpp_init()


def is_initialized():
    r'''Checks if the LIBGRPP library is initialized.
    '''
    return dll.libgrpp_is_initialized()


def finalize():
    r'''Optional finalization of the LIBGRPP library, to be called at exit.
    '''
    dll.libgrpp_finalize()


def overlap_integrals(shell_A, shell_B):
    r'''Overlap integrals <A|B>.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector

    Returns:
        matrix elements stored in a one-dimensional array (list of floats)
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)

    #
    # C function:
    # void libgrpp_overlap_integrals(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B, double *overlap_matrix);
    #
    dll.libgrpp_overlap_integrals.argtypes = [c_void_p, c_void_p, POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    c_matrix = (c_double * num_matrix_elements)()
    dll.libgrpp_overlap_integrals(c_shell_A, c_shell_B, c_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)

    return _c_array_to_python_list(c_matrix)


#
# void libgrpp_overlap_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *overlap_matrix)
#
def overlap_integrals_matrix(shell_list):

    dll.libgrpp_overlap_integrals_matrix.argtypes = [c_int, c_void_p, POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])

    num_matrix_elements = dim * dim
    c_matrix = (c_double * num_matrix_elements)()
    dll.libgrpp_overlap_integrals_matrix(num_shells, c_array_shells, c_matrix)

    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])

    return _c_array_to_python_list(c_matrix)


def kinetic_energy_integrals(shell_A, shell_B):
    r'''Kinetic-energy integrals <A| -1/2 \Delta |B>.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector

    Returns:
        matrix elements stored in a one-dimensional array (list of floats)
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)

    #
    # C function:
    # void libgrpp_kinetic_energy_integrals(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B, double *kinetic_matrix);
    #
    dll.libgrpp_kinetic_energy_integrals.argtypes = [c_void_p, c_void_p, POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    c_matrix = (c_double * num_matrix_elements)()
    dll.libgrpp_kinetic_energy_integrals(c_shell_A, c_shell_B, c_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)

    return _c_array_to_python_list(c_matrix)


#
# void libgrpp_kinetic_energy_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *overlap_matrix)
#
def kinetic_energy_integrals_matrix(shell_list):

    dll.libgrpp_kinetic_energy_integrals_matrix.argtypes = [c_int, c_void_p, POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])

    num_matrix_elements = dim * dim
    c_matrix = (c_double * num_matrix_elements)()
    dll.libgrpp_kinetic_energy_integrals_matrix(num_shells, c_array_shells, c_matrix)

    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])

    return _c_array_to_python_list(c_matrix)


def nuclear_attraction_integrals_point_charge(shell_A, shell_B, charge_origin, charge):
    r'''Nuclear attraction integrals <A| -Z/|R-r| |B>.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        charge_origin : 3-element list
            3D coordinates of a point charge (nucleus)
        charge : int or float
            point charge (fractional charges are allowed)

    Returns:
        matrix elements stored in a one-dimensional array (list of floats)
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)

    #
    # C function:
    # void libgrpp_nuclear_attraction_integrals_point_charge(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B,
    #     double *charge_origin, int charge, double *coulomb_matrix);
    #
    dll.libgrpp_nuclear_attraction_integrals_point_charge.argtypes = [c_void_p, c_void_p, POINTER(c_double), c_int,
                                                                      POINTER(c_double)]

    charge_origin_array = (c_double * 3)(*charge_origin)
    num_matrix_elements = shell_A.size() * shell_B.size()
    c_matrix = (c_double * num_matrix_elements)()
    dll.libgrpp_nuclear_attraction_integrals_point_charge(c_shell_A, c_shell_B, charge_origin_array, 1, c_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)

    array_for_Z_1 = _c_array_to_python_list(c_matrix)
    return [charge * array_for_Z_1[i] for i in range(0, num_matrix_elements)]


#
# void libgrpp_nuclear_attraction_integrals_point_charge_matrix(
#     int num_shells, libgrpp_shell_t **shell_list, double *charge_origin,
#     double charge, double *v_en_matrix)
#
def nuclear_attraction_integrals_point_charge_matrix(shell_list, charge_origin, charge):

    dll.libgrpp_nuclear_attraction_integrals_point_charge_matrix.argtypes =\
        [c_int, c_void_p, POINTER(c_double), c_double, POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])

    charge_origin_array = (c_double * 3)(*charge_origin)
    num_matrix_elements = dim * dim
    c_matrix = (c_double * num_matrix_elements)()
    dll.libgrpp_nuclear_attraction_integrals_point_charge_matrix(num_shells, c_array_shells, charge_origin_array, charge, c_matrix)

    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])

    return _c_array_to_python_list(c_matrix)


def type1_integrals(shell_A, shell_B, potential):
    r'''Integrals over a local effective potential (no angular projectors; "type-1" integrals).

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        potential : Potential
            Gaussian expansion of a local potential (no angular projectors)

    Returns:
        matrix elements stored in a one-dimensional array (list of floats)
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)
    c_potential = _create_c_potential(potential)

    #
    # C function:
    # void libgrpp_type1_integrals(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B, double *rpp_origin,
    #     libgrpp_potential_t *potential, double *matrix);
    #
    dll.libgrpp_type1_integrals.argtypes = [c_void_p, c_void_p, POINTER(c_double), c_void_p, POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    type1_c_array = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*potential.origin)

    dll.libgrpp_type1_integrals(c_shell_A, c_shell_B, rpp_origin_array, c_potential, type1_c_array)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    _delete_c_potential(c_potential)

    return _c_array_to_python_list(type1_c_array)


#
# void libgrpp_type1_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *rpp_origin,
#     libgrpp_potential_t *potential, double *arep_matrix)
#
def type1_integrals_matrix(shell_list, potential):

    dll.libgrpp_type1_integrals_matrix.argtypes =\
        [c_int, c_void_p, POINTER(c_double), c_void_p, POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    # python -> C
    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])
    c_potential = _create_c_potential(potential)

    num_matrix_elements = dim * dim
    c_matrix = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*potential.origin)

    dll.libgrpp_type1_integrals_matrix(num_shells, c_array_shells, rpp_origin_array, c_potential, c_matrix)

    # cleanup
    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])
    _delete_c_potential(c_potential)

    return _c_array_to_python_list(c_matrix)


def type2_integrals(shell_A, shell_B, potential):
    r'''Integrals over a semi-local scalar-relativistic effective potential
    (with angular projectors; "type-2" integrals).

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        potential : Potential
            Gaussian expansion of a semi-local scalar (averaged) potential
            (with angular projectors |l><l|)

    Returns:
        matrix elements stored in a one-dimensional array (list of floats)
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)
    c_potential = _create_c_potential(potential)

    #
    # C function:
    # void libgrpp_type2_integrals(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B, double *rpp_origin,
    #     libgrpp_potential_t *potential, double *matrix);
    #
    dll.libgrpp_type2_integrals.argtypes = [c_void_p, c_void_p, POINTER(c_double), c_void_p, POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    type2_c_array = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*potential.origin)

    dll.libgrpp_type2_integrals(c_shell_A, c_shell_B, rpp_origin_array, c_potential, type2_c_array)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    _delete_c_potential(c_potential)

    return _c_array_to_python_list(type2_c_array)


def type2_integrals_matrix(shell_list, potential):

    dll.libgrpp_type2_integrals_matrix.argtypes =\
        [c_int, c_void_p, POINTER(c_double), c_void_p, POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    # python -> C
    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])
    c_potential = _create_c_potential(potential)

    num_matrix_elements = dim * dim
    c_matrix = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*potential.origin)

    dll.libgrpp_type2_integrals_matrix(num_shells, c_array_shells, rpp_origin_array, c_potential, c_matrix)

    # cleanup
    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])
    _delete_c_potential(c_potential)

    return _c_array_to_python_list(c_matrix)


def spin_orbit_integrals(shell_A, shell_B, potential):
    r'''Integrals over a semi-local spin-orbit effective potential
    (with projectors; "type-3" integrals). LIBGRPP does not include the 's = 1/2 sigma' factor.
    Multiplication by 2 × 2 Pauli matrices sigma should be performed further at the stage of the
    construction of the Hamiltonian matrix.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        potential : Potential
            Gaussian expansion of a semi-local effective spin-orbit potential
            (with angular projectors |l> \vec{L} <l|)

    Returns:
        three one-dimensional arrays (lists of floats) containing matrix elements of
        SO_x, SO_y, SO_z effective operators.
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)
    c_potential = _create_c_potential(potential)

    #
    # C function:
    # void libgrpp_spin_orbit_integrals(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B, double *rpp_origin,
    #     libgrpp_potential_t *potential, double *so_x_matrix, double *so_y_matrix, double *so_z_matrix);
    #
    dll.libgrpp_spin_orbit_integrals.argtypes = [c_void_p, c_void_p, POINTER(c_double), c_void_p,
                                                 POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    spin_orbit_x_c_array = (c_double * num_matrix_elements)()
    spin_orbit_y_c_array = (c_double * num_matrix_elements)()
    spin_orbit_z_c_array = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*potential.origin)

    dll.libgrpp_spin_orbit_integrals(c_shell_A, c_shell_B, rpp_origin_array, c_potential,
                                     spin_orbit_x_c_array, spin_orbit_y_c_array, spin_orbit_z_c_array)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    _delete_c_potential(c_potential)

    return (_c_array_to_python_list(spin_orbit_x_c_array),
            _c_array_to_python_list(spin_orbit_y_c_array),
            _c_array_to_python_list(spin_orbit_z_c_array))

#
# void libgrpp_spin_orbit_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list, double *rpp_origin,
#     libgrpp_potential_t *potential, double *so_x_matrix, double *so_y_matrix, double *so_z_matrix)
#
def spin_orbit_integrals_matrix(shell_list, potential):

    dll.libgrpp_spin_orbit_integrals_matrix.argtypes =\
        [c_int, c_void_p, POINTER(c_double), c_void_p, POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    # python -> C
    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])
    c_potential = _create_c_potential(potential)

    num_matrix_elements = dim * dim
    c_matrix_so_x = (c_double * num_matrix_elements)()
    c_matrix_so_y = (c_double * num_matrix_elements)()
    c_matrix_so_z = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*potential.origin)

    dll.libgrpp_spin_orbit_integrals_matrix(num_shells, c_array_shells, rpp_origin_array, c_potential,
                                            c_matrix_so_x, c_matrix_so_y, c_matrix_so_z)

    # cleanup
    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])
    _delete_c_potential(c_potential)

    return (_c_array_to_python_list(c_matrix_so_x),
            _c_array_to_python_list(c_matrix_so_y),
            _c_array_to_python_list(c_matrix_so_z))


def outercore_potential_integrals(shell_A, shell_B, outercore_potentials, outercore_shells):
    r'''Integrals over a non-local part of a generalized relativistic pseudopotential
    (with projectors onto outercore shells).

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        outercore_potentials : list of Potential's
            list of outercore pseudopotentials U_{n_c, lj}
        outercore_shells : list of Shell's
            list of outercore shells |n_c, lj>

    Returns:
        four one-dimensional arrays (lists of floats) containing matrix elements of
        non-local parts of the averaged potential and the SO_x, SO_y, SO_z operators.
    '''
    if len(outercore_shells) != len(outercore_potentials):
        raise ValueError('lengths of arrays of outercore potentials and shells must be equal')

    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)

    num_oc_potentials = len(outercore_potentials)
    c_array_oc_potentials = (c_void_p * num_oc_potentials)()
    c_array_oc_shells = (c_void_p * num_oc_potentials)()

    for i in range(0, num_oc_potentials):
        c_array_oc_potentials[i] = _create_c_potential(outercore_potentials[i])
        c_array_oc_shells[i] = _create_c_shell(outercore_shells[i])

    #
    # C function:
    # void libgrpp_outercore_potential_integrals(
    #   libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B,
    #   double *rpp_origin, int num_oc_shells, libgrpp_potential_t **oc_potentials, libgrpp_shell_t **oc_shells,
    #   double *arep, double *esop_x, double *esop_y, double *esop_z);
    #
    dll.libgrpp_outercore_potential_integrals.argtypes = [c_void_p, c_void_p, POINTER(c_double), c_int,
                                                          POINTER(c_void_p), POINTER(c_void_p), POINTER(c_double),
                                                          POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    averaged_c_array = (c_double * num_matrix_elements)()
    spin_orbit_x_c_array = (c_double * num_matrix_elements)()
    spin_orbit_y_c_array = (c_double * num_matrix_elements)()
    spin_orbit_z_c_array = (c_double * num_matrix_elements)()
    rpp_origin_c_array = (c_double * 3)(*outercore_potentials[0].origin)

    dll.libgrpp_outercore_potential_integrals(c_shell_A, c_shell_B, rpp_origin_c_array,
                                              int(num_oc_potentials), c_array_oc_potentials, c_array_oc_shells,
                                              averaged_c_array, spin_orbit_x_c_array, spin_orbit_y_c_array,
                                              spin_orbit_z_c_array)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    for i in range(0, num_oc_potentials):
        _delete_c_potential(c_array_oc_potentials[i])
        _delete_c_shell(c_array_oc_shells[i])

    return (_c_array_to_python_list(averaged_c_array),
            _c_array_to_python_list(spin_orbit_x_c_array),
            _c_array_to_python_list(spin_orbit_y_c_array),
            _c_array_to_python_list(spin_orbit_z_c_array))


def full_grpp_integrals(shell_A, shell_B, grpp):
    r'''Integrals over a full generalized relativistic pseudopotential
    (local + semi-local + non-local terms).

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        grpp : GRPP
            object representing generalized relativistic pseudopotential which
            includes all terms (local, semi-local, non-local)

    Returns:
        four one-dimensional arrays (lists of floats) containing matrix elements of
        the averaged potential and the SO_x, SO_y, SO_z operators.
    '''
    size_A = shell_A.size()
    size_B = shell_B.size()
    num_matr_elements = size_A * size_B

    arep_matrix = [0] * num_matr_elements
    so_x_matrix = [0] * num_matr_elements
    so_y_matrix = [0] * num_matr_elements
    so_z_matrix = [0] * num_matr_elements

    # averaged scalar potential: local part
    arep_local = grpp.get_scalar_local_potential()
    if arep_local:
        integrals = type1_integrals(shell_A, shell_B, arep_local)
        for i in range(0, num_matr_elements):
            arep_matrix[i] += integrals[i]

    # averaged scalar potential: semi-local part
    arep_semilocal = grpp.get_scalar_semilocal_potentials()
    if arep_semilocal:
        for pot in arep_semilocal:
            integrals = type2_integrals(shell_A, shell_B, pot)
            for i in range(0, num_matr_elements):
                arep_matrix[i] += integrals[i]

    # spin-orbit potential: semi-local part
    esop_semilocal = grpp.get_spin_orbit_potentials()
    if esop_semilocal:
        for pot in esop_semilocal:
            factor = 2.0 / (2.0 * pot.L + 1.0)
            so_x, so_y, so_z = spin_orbit_integrals(shell_A, shell_B, pot)
            for i in range(0, num_matr_elements):
                so_x_matrix[i] += factor * so_x[i]
                so_y_matrix[i] += factor * so_y[i]
                so_z_matrix[i] += factor * so_z[i]

    # outercore non-local part (grpp-specific)
    outercore_potentials = grpp.get_outercore_potentials()
    outercore_shells = grpp.get_outercore_shells()
    if outercore_potentials and outercore_shells:
        arep, so_x, so_y, so_z = outercore_potential_integrals(shell_A, shell_B, outercore_potentials,
                                                               outercore_shells)
        for i in range(0, num_matr_elements):
            arep_matrix[i] += arep[i]
            so_x_matrix[i] += so_x[i]
            so_y_matrix[i] += so_y[i]
            so_z_matrix[i] += so_z[i]

    return arep_matrix, so_x_matrix, so_y_matrix, so_z_matrix


def full_grpp_integrals_version_2(shell_A, shell_B, grpp):
    r'''Integrals over a full generalized relativistic pseudopotential
    (local + semi-local + non-local terms): second version directly calling the
    corresponding C routine.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        grpp : GRPP
            object representing generalized relativistic pseudopotential which
            includes all terms (local, semi-local, non-local)

    Returns:
        four one-dimensional arrays (lists of floats) containing matrix elements of
        the averaged potential and the SO_x, SO_y, SO_z operators.
    '''

    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)
    c_grpp = _create_c_grpp(grpp)

    size_A = shell_A.size()
    size_B = shell_B.size()
    num_matrix_elements = size_A * size_B

    #
    # C function:
    # void libgrpp_full_grpp_integrals(
    #     libgrpp_shell_t *shell_A,
    #     libgrpp_shell_t *shell_B,
    #     libgrpp_grpp_t *grpp_operator,
    #     double *grpp_origin,
    #     double *arep_matrix,
    #     double *so_x_matrix,
    #     double *so_y_matrix,
    #     double *so_z_matrix
    # );
    #

    averaged_c_array = (c_double * num_matrix_elements)()
    spin_orbit_x_c_array = (c_double * num_matrix_elements)()
    spin_orbit_y_c_array = (c_double * num_matrix_elements)()
    spin_orbit_z_c_array = (c_double * num_matrix_elements)()
    rpp_origin_c_array = (c_double * 3)(*grpp.origin)

    dll.libgrpp_full_grpp_integrals.argtypes = [c_void_p, c_void_p, c_void_p, POINTER(c_double), POINTER(c_double),
                                                POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    dll.libgrpp_full_grpp_integrals(c_shell_A, c_shell_B, c_grpp, rpp_origin_c_array, averaged_c_array,
                                    spin_orbit_x_c_array, spin_orbit_y_c_array, spin_orbit_z_c_array)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    _delete_c_grpp(c_grpp)

    return (_c_array_to_python_list(averaged_c_array),
            _c_array_to_python_list(spin_orbit_x_c_array),
            _c_array_to_python_list(spin_orbit_y_c_array),
            _c_array_to_python_list(spin_orbit_z_c_array))


#
# void libgrpp_full_grpp_integrals_matrix(int num_shells, libgrpp_shell_t **shell_list,
#     libgrpp_grpp_t *grpp_operator, double *rpp_origin,
#     double *arep_matrix, double *so_x_matrix, double *so_y_matrix, double *so_z_matrix)
#
def full_grpp_integrals_matrix(shell_list, grpp):

    dll.libgrpp_full_grpp_integrals_matrix.argtypes =\
        [c_int, c_void_p, c_void_p, POINTER(c_double),
         POINTER(c_double), POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    dim = _cart_dim(shell_list)
    num_shells = len(shell_list)

    # python -> C
    c_array_shells = (c_void_p * num_shells)()
    for i in range(0, num_shells):
        c_array_shells[i] = _create_c_shell(shell_list[i])
    c_grpp = _create_c_grpp(grpp)

    num_matrix_elements = dim * dim
    c_matrix_arep = (c_double * num_matrix_elements)()
    c_matrix_so_x = (c_double * num_matrix_elements)()
    c_matrix_so_y = (c_double * num_matrix_elements)()
    c_matrix_so_z = (c_double * num_matrix_elements)()
    rpp_origin_array = (c_double * 3)(*grpp.origin)

    dll.libgrpp_full_grpp_integrals_matrix(num_shells, c_array_shells, c_grpp, rpp_origin_array,
                                           c_matrix_arep, c_matrix_so_x, c_matrix_so_y, c_matrix_so_z)

    # cleanup
    for i in range(0, num_shells):
        _delete_c_shell(c_array_shells[i])
    _delete_c_grpp(c_grpp)

    return (_c_array_to_python_list(c_matrix_arep),
            _c_array_to_python_list(c_matrix_so_x),
            _c_array_to_python_list(c_matrix_so_y),
            _c_array_to_python_list(c_matrix_so_z))


def overlap_integrals_gradient(shell_A, shell_B, point_3d):
    r'''Gradients of overlap integrals with respect to the given nuclear position:
    d<A|B>/dR

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        point_3d : 3-element list
            3D point

    Returns:
        three one-dimensional arrays (lists of floats) containing first derivatives of
        overlap matrix elements with respect to the coordinates of a point 'point_3d'.
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)

    #
    # C function:
    # void libgrpp_overlap_integrals_gradient_python(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B,
    #     double *point_3d, double *grad_x, double *grad_y, double *grad_z)
    #
    dll.libgrpp_overlap_integrals_gradient_python.argtypes = [c_void_p, c_void_p, POINTER(c_double),
                                                              POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    c_point_3d = (c_double * 3)()
    c_point_3d[0] = point_3d[0]
    c_point_3d[1] = point_3d[1]
    c_point_3d[2] = point_3d[2]

    num_matrix_elements = shell_A.size() * shell_B.size()
    c_grad_x_matrix = (c_double * num_matrix_elements)()
    c_grad_y_matrix = (c_double * num_matrix_elements)()
    c_grad_z_matrix = (c_double * num_matrix_elements)()

    dll.libgrpp_overlap_integrals_gradient_python(c_shell_A, c_shell_B, c_point_3d,
                                                  c_grad_x_matrix, c_grad_y_matrix, c_grad_z_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)

    return (_c_array_to_python_list(c_grad_x_matrix),
            _c_array_to_python_list(c_grad_y_matrix),
            _c_array_to_python_list(c_grad_z_matrix))


def overlap_integrals_gradient_bra(shell_A, shell_B):
    r'''Gradients of overlap integrals of type <nabla A|B>

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector

    Returns:
        three one-dimensional arrays (lists of floats) containing first derivatives of
        overlap matrix elements with respect to the coordinates of a point at which the
        shell_A (bra) is centered.
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)

    #
    # C function:
    # void libgrpp_overlap_integrals_gradient_bra_python(libgrpp_shell_t *shell_A, libgrpp_shell_t *shell_B,
    #     double *grad_x, double *grad_y, double *grad_z)
    #
    dll.libgrpp_overlap_integrals_gradient_bra_python.argtypes = [c_void_p, c_void_p,
                                                                  POINTER(c_double), POINTER(c_double),
                                                                  POINTER(c_double)]

    num_matrix_elements = shell_A.size() * shell_B.size()
    c_grad_x_matrix = (c_double * num_matrix_elements)()
    c_grad_y_matrix = (c_double * num_matrix_elements)()
    c_grad_z_matrix = (c_double * num_matrix_elements)()

    dll.libgrpp_overlap_integrals_gradient_bra_python(c_shell_A, c_shell_B,
                                                      c_grad_x_matrix, c_grad_y_matrix, c_grad_z_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)

    return (_c_array_to_python_list(c_grad_x_matrix),
            _c_array_to_python_list(c_grad_y_matrix),
            _c_array_to_python_list(c_grad_z_matrix))


def type1_integrals_gradient(shell_A, shell_B, pot, point_3d):
    r'''Gradients of type 1 pseudopotential integrals
    with respect to the given nuclear position: d<A|B>/dR

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        pot: Potential
            local pseudopotential (no angular projectors)
        point_3d : 3-element list
            3D point

    Returns:
        three one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point 'point_3d'.
    '''
    grpp = GRPP(pot.origin)
    grpp.set_scalar_local_potential(pot)

    return full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d)[:3]


def type1_integrals_gradient_bra(shell_A, shell_B, pot):
    r'''Gradients of type 1 pseudopotential integrals of type <nabla A|U|B>

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        pot: Potential
            local pseudopotential (no angular projectors)

    Returns:
        three one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point at which the
        shell_A (bra) is centered.
    '''
    grpp = GRPP(pot.origin)
    grpp.set_scalar_local_potential(pot)

    return full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp)[:3]


def type2_integrals_gradient(shell_A, shell_B, pot, point_3d):
    r'''Gradients of type 2 pseudopotential integrals
    with respect to the given nuclear position: d<A|B>/dR

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        pot: Potential
            semi-local pseudopotential (with angular projectors)
        point_3d : 3-element list
            3D point

    Returns:
        three one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point 'point_3d'.
    '''
    assert pot.L >= 0

    grpp = GRPP(pot.origin)
    grpp.add_scalar_semilocal_potential(pot)

    return full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d)[:3]


def type2_integrals_gradient_bra(shell_A, shell_B, pot):
    r'''Gradients of type 2 pseudopotential integrals of type <nabla A|U|B>

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        pot: Potential
            semi-local pseudopotential (with angular projectors)

    Returns:
        three one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point at which the
        shell_A (bra) is centered.
    '''
    assert pot.L >= 0

    grpp = GRPP(pot.origin)
    grpp.add_scalar_semilocal_potential(pot)

    return full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp)[:3]


def spin_orbit_integrals_gradient(shell_A, shell_B, pot, point_3d):
    r'''Gradients of spin-orbit effective potential ("type 3") integrals
    with respect to the given nuclear position: d<A|B>/dR

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        pot: Potential
            semi-local effective spin-orbit potential (with angular projectors)
        point_3d : 3-element list
            3D point

    Returns:
        nine one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point 'point_3d'.
        Order or matrices:
        [d<SO_x>/dX, d<SO_x>/dY, d<SO_x>/dZ,
        d<SO_y>/dX, d<SO_y>/dY, d<SO_y>/dZ,
        d<SO_z>/dX, d<SO_z>/dY, d<SO_z>/dZ]
    '''
    assert pot.L >= 1

    grpp = GRPP(pot.origin)
    grpp.add_spin_orbit_potential(pot)

    return full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d)[3:]


def spin_orbit_integrals_gradient_bra(shell_A, shell_B, pot):
    r'''Gradients of spin-orbit effective potential ("type 3") integrals
    of type <nabla A|U|B>.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        pot: Potential
            semi-local effective spin-orbit potential (with angular projectors)

    Returns:
        nine one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point at which the
        shell_A (bra) is centered.
        Order or matrices:
        [d<SO_x>/dX, d<SO_x>/dY, d<SO_x>/dZ,
        d<SO_y>/dX, d<SO_y>/dY, d<SO_y>/dZ,
        d<SO_z>/dX, d<SO_z>/dY, d<SO_z>/dZ]
    '''
    assert pot.L >= 1

    grpp = GRPP(pot.origin)
    grpp.add_spin_orbit_potential(pot)

    return full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp)[3:]


def full_grpp_integrals_gradient(shell_A, shell_B, grpp, point_3d):
    r'''Gradients of GRPP integrals with respect to the given nuclear position: d<A|B>/dR

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        grpp: GRPP
            full generalized relativistic pseudopotential
        point_3d : 3-element list
            3D point

    Returns:
        12 one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point 'point_3d'.
        Order or matrices:
        [d<AREP>/dX, d<AREP>/dY, d<AREP>/dZ,
        d<SO_x>/dX, d<SO_x>/dY, d<SO_x>/dZ,
        d<SO_y>/dX, d<SO_y>/dY, d<SO_y>/dZ,
        d<SO_z>/dX, d<SO_z>/dY, d<SO_z>/dZ]
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)
    c_grpp = _create_c_grpp(grpp)

    dll.libgrpp_full_grpp_integrals_gradient_python.argtypes = [c_void_p, c_void_p, c_void_p,
                                                                POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    c_point_3d = (c_double * 3)(*point_3d)
    c_origin = (c_double * 3)(*grpp.origin)

    num_matrix_elements = shell_A.size() * shell_B.size()

    c_grad_x_arep_matrix = (c_double * num_matrix_elements)()
    c_grad_y_arep_matrix = (c_double * num_matrix_elements)()
    c_grad_z_arep_matrix = (c_double * num_matrix_elements)()

    c_grad_x_so_x_matrix = (c_double * num_matrix_elements)()
    c_grad_y_so_x_matrix = (c_double * num_matrix_elements)()
    c_grad_z_so_x_matrix = (c_double * num_matrix_elements)()

    c_grad_x_so_y_matrix = (c_double * num_matrix_elements)()
    c_grad_y_so_y_matrix = (c_double * num_matrix_elements)()
    c_grad_z_so_y_matrix = (c_double * num_matrix_elements)()

    c_grad_x_so_z_matrix = (c_double * num_matrix_elements)()
    c_grad_y_so_z_matrix = (c_double * num_matrix_elements)()
    c_grad_z_so_z_matrix = (c_double * num_matrix_elements)()

    #
    # C function:
    # void libgrpp_full_grpp_integrals_gradient_python(
    #     libgrpp_shell_t *shell_A,
    #     libgrpp_shell_t *shell_B,
    #     libgrpp_grpp_t *grpp_operator,
    #     double *grpp_origin,
    #     double *point_3d,
    #     double *grad_x_arep,
    #     double *grad_y_arep,
    #     double *grad_z_arep,
    #     double *grad_x_so_x,
    #     double *grad_y_so_x,
    #     double *grad_z_so_x,
    #     double *grad_x_so_y,
    #     double *grad_y_so_y,
    #     double *grad_z_so_y,
    #     double *grad_x_so_z,
    #     double *grad_y_so_z,
    #     double *grad_z_so_z
    # )
    #
    dll.libgrpp_full_grpp_integrals_gradient_python(c_shell_A, c_shell_B, c_grpp, c_origin, c_point_3d,
                                                    c_grad_x_arep_matrix, c_grad_y_arep_matrix, c_grad_z_arep_matrix,
                                                    c_grad_x_so_x_matrix, c_grad_y_so_x_matrix, c_grad_z_so_x_matrix,
                                                    c_grad_x_so_y_matrix, c_grad_y_so_y_matrix, c_grad_z_so_y_matrix,
                                                    c_grad_x_so_z_matrix, c_grad_y_so_z_matrix, c_grad_z_so_z_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    _delete_c_grpp(c_grpp)

    return (_c_array_to_python_list(c_grad_x_arep_matrix),
            _c_array_to_python_list(c_grad_y_arep_matrix),
            _c_array_to_python_list(c_grad_z_arep_matrix),
            _c_array_to_python_list(c_grad_x_so_x_matrix),
            _c_array_to_python_list(c_grad_y_so_x_matrix),
            _c_array_to_python_list(c_grad_z_so_x_matrix),
            _c_array_to_python_list(c_grad_x_so_y_matrix),
            _c_array_to_python_list(c_grad_y_so_y_matrix),
            _c_array_to_python_list(c_grad_z_so_y_matrix),
            _c_array_to_python_list(c_grad_x_so_z_matrix),
            _c_array_to_python_list(c_grad_y_so_z_matrix),
            _c_array_to_python_list(c_grad_z_so_z_matrix))


def full_grpp_integrals_gradient_bra(shell_A, shell_B, grpp):
    r'''Gradients of GRPP integrals of type <nabla A|U|B>.

    Args:
        shell_A : Shell
            bra vector
        shell_B : Shell
            ket vector
        grpp: GRPP
            full generalized relativistic pseudopotential

    Returns:
        12 one-dimensional arrays (lists of floats) containing first derivatives of
        matrix elements with respect to the coordinates of a point at which the
        shell_A (bra) is centered.
        Order or matrices:
        [d<AREP>/dX, d<AREP>/dY, d<AREP>/dZ,
        d<SO_x>/dX, d<SO_x>/dY, d<SO_x>/dZ,
        d<SO_y>/dX, d<SO_y>/dY, d<SO_y>/dZ,
        d<SO_z>/dX, d<SO_z>/dY, d<SO_z>/dZ]
    '''
    c_shell_A = _create_c_shell(shell_A)
    c_shell_B = _create_c_shell(shell_B)
    c_grpp = _create_c_grpp(grpp)

    dll.libgrpp_full_grpp_integrals_gradient_bra_python.argtypes = [c_void_p, c_void_p, c_void_p, POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double),
                                                                POINTER(c_double), POINTER(c_double), POINTER(c_double)]

    c_origin = (c_double * 3)(*grpp.origin)

    num_matrix_elements = shell_A.size() * shell_B.size()

    c_grad_x_arep_matrix = (c_double * num_matrix_elements)()
    c_grad_y_arep_matrix = (c_double * num_matrix_elements)()
    c_grad_z_arep_matrix = (c_double * num_matrix_elements)()

    c_grad_x_so_x_matrix = (c_double * num_matrix_elements)()
    c_grad_y_so_x_matrix = (c_double * num_matrix_elements)()
    c_grad_z_so_x_matrix = (c_double * num_matrix_elements)()

    c_grad_x_so_y_matrix = (c_double * num_matrix_elements)()
    c_grad_y_so_y_matrix = (c_double * num_matrix_elements)()
    c_grad_z_so_y_matrix = (c_double * num_matrix_elements)()

    c_grad_x_so_z_matrix = (c_double * num_matrix_elements)()
    c_grad_y_so_z_matrix = (c_double * num_matrix_elements)()
    c_grad_z_so_z_matrix = (c_double * num_matrix_elements)()

    #
    # C function:
    # void libgrpp_full_grpp_integrals_gradient_bra_python(
    #     libgrpp_shell_t *shell_A,
    #     libgrpp_shell_t *shell_B,
    #     libgrpp_grpp_t *grpp_operator,
    #     double *grpp_origin,
    #     double *grad_x_arep,
    #     double *grad_y_arep,
    #     double *grad_z_arep,
    #     double *grad_x_so_x,
    #     double *grad_y_so_x,
    #     double *grad_z_so_x,
    #     double *grad_x_so_y,
    #     double *grad_y_so_y,
    #     double *grad_z_so_y,
    #     double *grad_x_so_z,
    #     double *grad_y_so_z,
    #     double *grad_z_so_z
    # )
    #
    dll.libgrpp_full_grpp_integrals_gradient_bra_python(c_shell_A, c_shell_B, c_grpp, c_origin,
                                                    c_grad_x_arep_matrix, c_grad_y_arep_matrix, c_grad_z_arep_matrix,
                                                    c_grad_x_so_x_matrix, c_grad_y_so_x_matrix, c_grad_z_so_x_matrix,
                                                    c_grad_x_so_y_matrix, c_grad_y_so_y_matrix, c_grad_z_so_y_matrix,
                                                    c_grad_x_so_z_matrix, c_grad_y_so_z_matrix, c_grad_z_so_z_matrix)

    _delete_c_shell(c_shell_A)
    _delete_c_shell(c_shell_B)
    _delete_c_grpp(c_grpp)

    return (_c_array_to_python_list(c_grad_x_arep_matrix),
            _c_array_to_python_list(c_grad_y_arep_matrix),
            _c_array_to_python_list(c_grad_z_arep_matrix),
            _c_array_to_python_list(c_grad_x_so_x_matrix),
            _c_array_to_python_list(c_grad_y_so_x_matrix),
            _c_array_to_python_list(c_grad_z_so_x_matrix),
            _c_array_to_python_list(c_grad_x_so_y_matrix),
            _c_array_to_python_list(c_grad_y_so_y_matrix),
            _c_array_to_python_list(c_grad_z_so_y_matrix),
            _c_array_to_python_list(c_grad_x_so_z_matrix),
            _c_array_to_python_list(c_grad_y_so_z_matrix),
            _c_array_to_python_list(c_grad_z_so_z_matrix))


def _c_array_to_python_list(c_array_double):
    return c_array_double #[c_array_double[i] for i in range(0, len(c_array_double))]


def _cart_dim(shell_list):
    dim_cart_basis = 0
    for shell in shell_list:
        dim_cart_basis += shell.size()
    return dim_cart_basis
