import numpy as np
from pyscf import gto, scf, ao2mo, geomopt, symm, mp, mcscf, symm, lib
from functools import reduce
import numpy, math
import os, sys

class FCIDUMPGenerator:
    MOLPRO_ID = { 
        'D2h': {'Ag': 1, 'B1g': 4, 'B2g': 6, 'B3g': 7, 'Au': 8, 'B1u': 5, 'B2u': 3, 'B3u': 2},
        'C2v': {'A1': 1, 'A2': 4, 'B1': 2, 'B2': 3},
        'C2h': {'Ag': 1, 'Bg': 4, 'Au': 2, 'Bu': 3},
        'D2': {'A': 1, 'B1': 4, 'B2': 3, 'B3': 2},
        'Cs': {"A'": 1, 'A"': 2},
        'C2': {'A': 1, 'B': 2},
        'Ci': {'Ag': 1, 'Au': 2},
        'C1': {'A': 1},
    } # Словарь, который сопоставляет группы симметрии (точечные группы) и соответствующие им символьные обозначения симметрии молекулярных орбиталей (из PySCF) с числовыми идентификаторами (используемыми в Molpro).

    @staticmethod
    def format_numb(number): # Определение статического метода, который форматирует число в научную нотацию
        if number == 0:
            return " 0.0000000000000000E+00"
        
        rate = int(math.log10(abs(number))) # Вычисляем порядок числа через логарифм по основанию 10
        
        if abs(number) >= 1:
            mantissa = number / 10**(rate+1)
            exp = rate + 1
        elif abs(number) == 0.1:
            mantissa = number / 10**(rate+1)
            exp = abs(rate + 1)
        else:
            mantissa = number / 10**rate
            exp = abs(rate)

        sign = ' ' if number > 0 else ''  # Если число положительное, добавляется пробел (для выравнивания)
        exp_sign = '+' if (abs(number) >= 0.1) else '-' # Определяем знак степени
        add_zero = '0' * (2 - len(str(exp)))  # Добавляем ведущие нули, чтобы длина степени была не менее 2 символов
        formatted_number = f"{sign}{mantissa:0.16f}E{exp_sign}{add_zero}{exp}" # Форматируем число: знак, мантисса с 16 знаками после запятой, степень с правильным знаком и ведущими нулями
        return formatted_number

    def __init__(self, mol, method, frozen_indices = [], low_mem = False, tolerance = 1e-15, occupations = None): #инициализация обьекта класса
        self.low_mem = low_mem # Флаг для режима низкого потребления памяти
        self.mol = mol # Сохранение объекта молекулы
        self.method = method # Сохранение используемого метода расчета (из него берем интегралы и все необходимое)
        self.norb = mol.nao_nr() # Количество атомных орбиталей в молекуле
        self.nelec = mol.nelectron # Количество электронов в молекуле
        self.ms2 = method.mol.spin # Спиновое состояние системы
        #self.wfnsym = method.fcisolver.wfnsym # Симметрия полной волновой функции
        self.tolerance = tolerance # Минимальное значение интеграла для его записи в файл
        mo_coeff = method.mo_coeff # Неотсортированные коэффициенты молекулярных орбиталей
        
        # Определение симметрии орбиталей, сортировка и перевод в строковый вид для записи
        orbsym = [self.MOLPRO_ID[mol.groupname][i]
                for i in symm.label_orb_symm(mol, mol.irrep_name, mol.symm_orb, mo_coeff)]
        orbsym_rem = np.array(orbsym)[np.isin(np.arange(len(orbsym)), frozen_indices, invert=True)] # Исключение замороженных орбиталей из массива симметрий
        orbsym_sort = np.array(sorted(orbsym_rem))

        self.orbsym_str = ','.join(map(str, orbsym_sort))
        # создание массива индексов соответсвия для сортировки в соответсвии с сортировкой orbsym
        indexed_arr = list(enumerate(orbsym))
        sorted_arr = sorted(indexed_arr, key=lambda x: x[1])
        self.sorted_indices = [x[0] for x in sorted_arr]
        del sorted_arr, orbsym_rem, indexed_arr, orbsym, orbsym_sort # Освобождение памяти
        
        self.frozen_indices = np.where(np.isin(self.sorted_indices, frozen_indices))[0] # Сортировка для соответствия с orbsym

        if self.low_mem: # Если активен режим низкого потребления памяти
            self.int2e_mo = np.memmap('int2e_mo.dat', dtype='float64', mode='w+', shape=(self.norb, self.norb, self.norb, self.norb)) # Создание файла для хранения двухэлектронных интегралов на диске с использованием memory-mapped файла

            self.int2e_mo[:] = ao2mo.restore("1", ao2mo.kernel(mol, mo_coeff), self.norb)  # Получение двухэлектронных интегралов в представлении молекулярных орбиталей
            self.int2e_mo.flush() # Сохранение данных на диск
            self.int2e_mo[:] = self.int2e_mo[np.ix_(self.sorted_indices, self.sorted_indices, self.sorted_indices, self.sorted_indices)] # Сортировка для соответствия с orbsym
            self.int2e_mo.flush() # Сохранение изменений на диск
        else:
            self.int2e_mo = ao2mo.restore("1", ao2mo.kernel(mol, mo_coeff), self.norb) # Получения двухэлектронных интегралов в представлении молекулярных орбиталей (с хранением их в оперативной памяти)
            self.int2e_mo[:] = self.int2e_mo[np.ix_(self.sorted_indices, self.sorted_indices, self.sorted_indices, self.sorted_indices)] # Сортировка для соответствия с orbsym

        self.mo_coeff = mo_coeff[self.sorted_indices][:, self.sorted_indices] # Сортировка для соответствия с orbsym

        if occupations is None: # Если заселённости орбиталей не заданы, назначаем им значение 2.0
            occupations = [2.0] * len(self.frozen_indices)
        elif len(occupations) != len(self.frozen_indices):
            raise ValueError("Количество заселенностей должно соответствовать количеству замораживаемых орбиталей")
        self.occupations = occupations # Сохранение заселённостей орбиталей

        int1e_mo = reduce(numpy.dot, (mo_coeff.T, method.get_hcore(self.mol), mo_coeff))[self.sorted_indices][:, self.sorted_indices] # Получение одноэлектронных интегралов в представлении молекулярных орбиталей с сортировкой для соответствия с orbsym
        del mo_coeff # Освобождение памяти после завершения вычислений
        E_const_1e = sum(occ * int1e_mo[f, f] for f, occ in zip(self.frozen_indices, occupations)) # Расчет вклада одноэлектронных энергий от замороженных орбиталей
        del int1e_mo # Освобождение памяти после вычислений
        E_const_2e = 0.5 * sum(occ1 * occ2 * (self.int2e_mo[f1, f1, f2, f2] - 0.5 * self.int2e_mo[f1, f2, f2, f1]) 
                            for (f1, occ1) in zip(self.frozen_indices, occupations) 
                            for (f2, occ2) in zip(self.frozen_indices, occupations)) # Расчет вклада двухэлектронных взаимодействий между замороженными орбиталями

        self.frozen_energy = method.energy_nuc() + E_const_1e + E_const_2e  # Сохранение итоговой энергии системы с учётом вклада замороженных орбиталей и ядерной энергии

    def WriteFCIDUMP(self, output_filename = "FCIDUMP"):
        # Форматирование заголовка
        header = f" &FCI NORB= {self.norb - len(self.frozen_indices)},NELEC= {self.nelec- 2*len(self.frozen_indices)},MS2= {self.ms2},\n"
        header += f"  ORBSYM={self.orbsym_str},\n"
        #header += f"  ISYM={self.wfnsym},\n /\n" #!!!!!!!!!!!!!!!!!!!!!
        header += f"  ISYM=1,\n /\n"
        # И запись заголовка
        with open(output_filename, "w") as f:
            f.write(header)
        # Сортировка, удаление замороженных орбиталей и запись двуэлектронных интегралов
        self.freeze_and_remove_orbital_2e(output_filename)
        # Получение одноэлектронных интегралов, удаление замороженных орбиталей, преобразование оставшихся и запись
        self.freeze_and_remove_orbital_1e(output_filename)

        print(f"Nuclear repulsion + frozen core energy = {self.frozen_energy}")
        
        # Запись в файл энергии системы с учётом вклада замороженных орбиталей и ядерной энергии
        with open(output_filename, "a") as f:
            f.write(f" {self.format_numb(self.frozen_energy)}   0   0   0   0\n")
        print(f"Results has been written to {output_filename}")
        return 1

    def freeze_and_remove_orbital_1e(self, output_filename): # Получение, удаление замороженных орбиталей, преобразование оставшихся и запись одноэлектронных интегралов
        if self.low_mem: # Если используется режим с низким потреблением памяти
            int2e_ao = np.memmap('int2e_ao.dat', dtype='float64', mode='w+', shape=(self.norb, self.norb, self.norb, self.norb)) # Создание memory-mapped файла
            int2e_ao[:] = self.mol.intor('int2e') # Получение двухэлектронных интегралов в базисе атомных орбиталей
            int2e_ao.flush() # Сохранение изменений на диск
            int2e_ao[:] = int2e_ao[np.ix_(self.sorted_indices, self.sorted_indices, self.sorted_indices, self.sorted_indices)] #Сортировка
            int2e_ao.flush() # Сохранение изменений на диск
        else:
            int2e_ao = self.mol.intor('int2e')[np.ix_(self.sorted_indices, self.sorted_indices, self.sorted_indices, self.sorted_indices)] # Получение двухэлектронных интегралов в базисе атомных орбиталей (с сохранение в оперативную память)

        int1e = (self.mol.intor('int1e_kin') + self.mol.intor('int1e_nuc'))[np.ix_(self.sorted_indices, self.sorted_indices)] # Получение одноэлектронных интегралов в базисе атомных орбиталей и их сортировка
        
        veff_ecp = self.mol.intor('ECPscalar')[np.ix_(self.sorted_indices, self.sorted_indices)] #!!!!!!!!!!!!!!!!!!!!!!!!
        int1e += veff_ecp #!!!!!!!!!!!!!!!!!!!!!!!
        del veff_ecp

        P = np.zeros((self.mo_coeff.shape[0], self.mo_coeff.shape[0])) # Инициализация матрицы плотности
        for i in self.frozen_indices: # Заполнение матрицы плотности для замороженных орбиталей
            P += self.occupations[i] * np.outer(self.mo_coeff[:, i], self.mo_coeff[:, i])
        
        int1e += np.einsum('pqrs,pq->rs', int2e_ao, P) - np.einsum('pqrs,ps->qr', int2e_ao, P)/2 # Коррекция одноэлектронных интегралов с учётом двухэлектронных взаимодействий от замороженных орбиталей

        del P, int2e_ao  # Удаление временных переменных для освобождения памяти
        if os.path.exists('int2e_ao.dat'): # Удаление временного файла на диске
            os.remove('int2e_ao.dat')

        # Преобразование одноэлектронных интегралов в базис МО
        int1e = np.einsum('pi,pq,qj->ij', self.mo_coeff, int1e, self.mo_coeff)
        del self.mo_coeff # Освобождение памяти

        mask = np.ones(int1e.shape[0], dtype=bool) # Создание маски для исключения замороженных орбиталей
        mask[self.frozen_indices] = False # Помечаем замороженные орбитали как исключённые
        int1e = int1e[mask][:, mask] # Применение маски к матрице одноэлектронных интегралов
        del mask # Освобождение памяти

        with open(output_filename, "a") as f: # Запись одноэлектронных интегралов в файл
            for i in range(int1e.shape[0]):
                for j in range(i + 1):
                    value = int1e[i, j]
                    if abs(value) > self.tolerance: # Если значение больше заданного tolerance
                        f.write(f" {self.format_numb(value)}" +   "{:>4} {:>3} {:>3} {:>3}".format(i+1, j+1, 0, 0) + "\n")
        del int1e # Освобождение памяти
        return 1

    def freeze_and_remove_orbital_2e(self, output_filename): # Сортировка, удаление замороженных орбиталей и запись двуэлектронных интегралов
        n = self.int2e_mo.shape[0] # Получаем размер матрицы
        mask = np.ones(n, dtype=bool) # Создаем маску, которая будет исключать замороженные орбитали
        mask[self.frozen_indices] = False # Помечаем замороженные орбитали как исключённые
        indices = np.where(mask)[0] # Получаем индексы орбиталей, которые не были заморожены

        if self.low_mem: # Если используется режим с низким потреблением памяти
            int2e_rem = np.memmap('int2e_rem.dat', dtype='float64', mode='w+', shape=(self.norb - len(self.frozen_indices), self.norb - len(self.frozen_indices), self.norb- len(self.frozen_indices), self.norb - len(self.frozen_indices))) # Создаем memory-mapped файл для хранения двухэлектронных интегралов для оставшихся орбиталей
            int2e_rem[:] = self.int2e_mo[np.ix_(indices, indices, indices, indices)] # Заполняем его данными без замороженных орбиталей
            int2e_rem.flush() # Сохраняем изменения на диск
        else:
            int2e_rem = self.int2e_mo[np.ix_(indices, indices, indices, indices)] # Просто сохраняем двухэлектронные интегралы в оперативной памяти
        del mask, indices, self.int2e_mo # Освобождаем память
        if os.path.exists('int2e_mo.dat'): # Удаляем временный файл на диске
            os.remove('int2e_mo.dat')

        n = int2e_rem.shape[0] # Получаем новое количество орбиталей после удаления замороженных
        # Записываем оставшиеся двухэлектронные интегралы в файл
        with open(output_filename, "a") as f:
            for i in range(n): 
                for j in range(i + 1):
                    ij = i * (i + 1) // 2 + j
                    for k in range(n):
                        for l in range(k + 1):
                            kl = k * (k + 1) // 2 + l
                            if ij >= kl:  # Это условие обеспечивает 8-кратную симметрию
                                value = int2e_rem[i, j, k, l] # Достаем значение интеграла
                                if abs(value) > self.tolerance: # Если значение больше заданного tolerance
                                    f.write(f" {self.format_numb(value)}" +   "{:>4} {:>3} {:>3} {:>3}".format(i+1, j+1, k+1, l+1) + "\n")
        del int2e_rem # Освобождаем память
        if os.path.exists('int2e_rem.dat'): # Удаляем временный файл с диска
            os.remove('int2e_rem.dat')
        return 1